package com.infy.ui;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.GregorianCalendar;
import java.util.HashSet;
import java.util.List;

import com.infy.infyretailapp.bean.Address;
import com.infy.infyretailapp.bean.Gender;
import com.infy.infyretailapp.bean.Offers;
import com.infy.infyretailapp.bean.Order;
import com.infy.infyretailapp.bean.OrderProduct;
import com.infy.infyretailapp.bean.Product;
import com.infy.infyretailapp.bean.RetailOutlet;
import com.infy.infyretailapp.bean.User;
import com.infy.infyretailapp.bean.UserRole;
import com.infy.infyretailapp.bean.UserType;
import com.infy.infyretailapp.business.service.OrderService;
import com.infy.infyretailapp.business.service.ProductService;
import com.infy.infyretailapp.business.service.RetailOfferService;
import com.infy.infyretailapp.business.service.UserService;
import com.infy.infyretailapp.resources.AppConfig;
import com.infy.infyretailapp.resources.Factory;
import com.infy.infyretailapp.resources.HibernateUtility;

/**
 * Creates the bean object and calls the methods in the Service classes. This is
 * a temporary class and will be replaced once the client tier is developed
 * 
 * @author ETA
 */

public class UserInterface {
	private static UserService userService = Factory.createUserService();
	private static ProductService productService = Factory
			.createProductService();
	private static OrderService orderService = Factory.createOrderService();
	private static RetailOfferService retailOfferService = Factory
			.createRetailOfferService();

	public static void main(String[] args) {
		try {
			// USER MODULES
			// addUser();
			// updateUser();
			// changePassword();
			findUser();
			// deactivateUser();
			// getAllUsers();

			// PRODUCT MODULES
			// addProduct();
			// updateProduct();
			// deleteProduct();
			// getProductDetails();
			// getProductsInPriceRange();
			// getCountOfProducts();

			// ORDER MODULES
			// placeOrder();
			// getOrderProductDetails();
			// viewOrder();
			// showOrdersByUser();
			// showOrdersByDate();

			// HQL//Criteria
			// getAllUsers();
			// getProductsInPriceRange();
			// showOrdersByUser();
			// showOrdersByDate();
			// getCountOfProducts();

			// Many to many

			// addRetailOutletAndExistingOffer();
			// deleteOffersForRetailOutlet();
			// addNewOffersToExistingRetail();
			// getAllOfferForRetail();

		} finally {
			HibernateUtility.closeSessionFactory();
		}
	}

	// HQL

	private static void deleteOffersForRetailOutlet() {
		// TODO Auto-generated method stub

		Integer retailOutletId = 5003;

		List<Offers> offers = new ArrayList<Offers>();
		Offers offer1 = new Offers();
		offer1.setOfferId(2002);
		Offers offer2 = new Offers();
		offer2.setOfferId(2003);

		offers.add(offer1);
		offers.add(offer2);

		RetailOutlet retailOutlet = new RetailOutlet();
		retailOutlet.setRetailOutletId(retailOutletId);
		retailOutlet.setOffers(offers);

		try {
			Integer outletId = null;
			outletId = retailOfferService.deleteOffersForRetailOutlet(
					retailOutletId, offers);
			System.out.println(AppConfig.PROPERTIES
					.getProperty("UserInterface.UPDATE_RETAIL_OFFER_SUCCESS")
					+ outletId);

		} catch (Exception e) {
			e.printStackTrace();
			System.out
					.println(AppConfig.PROPERTIES.getProperty(e.getMessage()));
		}

	}

	private static void addRetailOutletAndExistingOffer() {
		// TODO Auto-generated method stub

		Integer retailOutletId = 5003;
		String retailOutletName = "Infy Levis";
		String city = "Chennai";
		List<Offers> offers = new ArrayList<Offers>();
		Offers obj = new Offers();
		obj.setOfferId(2001);

		Offers obj1 = new Offers();
		obj1.setOfferId(2002);

		Offers obj2 = new Offers();
		obj2.setOfferId(2003);

		offers.add(obj);
		offers.add(obj1);
		offers.add(obj2);

		RetailOutlet retailOutlet = new RetailOutlet();
		retailOutlet.setRetailOutletId(retailOutletId);
		retailOutlet.setRetailOutletName(retailOutletName);
		retailOutlet.setCity(city);
		retailOutlet.setOffers(offers);

		try {
			RetailOutlet outlet = retailOfferService
					.addRetailOutletAndExistingOffer(retailOutlet);
			System.out.print(AppConfig.PROPERTIES
					.getProperty("UserInterface.ADD_RETAIL_OFFER_SUCCESS"));
			for (Offers offers2 : outlet.getOffers()) {
				System.out.print(" " + offers2.getOfferId() + " ");
			}

		} catch (Exception e) {
			System.out
					.println(AppConfig.PROPERTIES.getProperty(e.getMessage()));
		}

	}

	public static void addNewOffersToExistingRetail() {

		try {
			Offers offer1 = new Offers();
			offer1.setOfferId(2005);
			offer1.setMonth("October");
			offer1.setOfferName("Dasara Dhamaka");

			Offers offer2 = new Offers();
			offer2.setOfferId(2006);
			offer2.setMonth("June");
			offer2.setOfferName("Ramadhan Offers");

			List<Offers> offerList = new ArrayList<Offers>();
			offerList.add(offer1);
			offerList.add(offer2);

			RetailOutlet retail = new RetailOutlet();
			retail.setRetailOutletId(5001);
			retail.setOffers(offerList);

			retailOfferService.addNewOffersToExistingRetail(retail);
			System.out.println("New Offers have been added to Retail outlet:"
					+ retail.getRetailOutletId());

		} catch (Exception e) {
			System.out
					.println(AppConfig.PROPERTIES.getProperty(e.getMessage()));
		}

	}

	public static void getAllOfferForRetail() {
		try {
			List<Offers> offerList = retailOfferService
					.getAllOfferForRetail(new Integer(5001));

			System.out.printf("%-11s%-20s%-12s%n", "Offer ID", "Offer Name",
					"Offer Date");

			System.out.printf("%-11s%-20s%-12s%n", "========", "============",
					"=========");
			for (Offers offer : offerList) {
				System.out.printf("%-11s%-20s%-12s%n", offer.getOfferId(),
						offer.getOfferName(), offer.getMonth());
			}
		} catch (Exception e) {
			System.out
					.println(AppConfig.PROPERTIES.getProperty(e.getMessage()));
		}
	}

	@SuppressWarnings("unused")
	private static void getCountOfProducts() {

		String supplierId = "S101";

		try {
			Long count = productService.getCountOfProducts(supplierId);
			System.out.println("The supplier " + supplierId + " has supplied "
					+ count + " products");
		} catch (Exception e) {
			System.out
					.println(AppConfig.PROPERTIES.getProperty(e.getMessage()));
		}

	}

	public static void getAllUsers() {
		try {
			String userRole = "C";
			List<User> userList = userService.getAllUsers(userRole);
			System.out.printf("%-10s%-20s%-16s%-13s%-10s%n", "User ID",
					"Username", "Mobile Number", "Role", "Type");
			System.out.printf("%-10s%-20s%-16s%-13s%-10s%n", "=======",
					"=================", "=============", "==========",
					"==========");
			for (User user : userList) {
				System.out.printf("%-10s%-20s%-16s%-13s%-10s%n",
						user.getUserId(), user.getUserName(),
						user.getMobileNumber(), user.getUserRole(),
						user.getUserType());
			}
		} catch (Exception e) {
			System.out
					.println(AppConfig.PROPERTIES.getProperty(e.getMessage()));
		}
	}

	public static void getProductsInPriceRange() {
		try {
			List<Product> productList = productService.getProductsInPriceRange(
					1000.0, 2000.0);
			System.out.printf(
					"%-12s%-27s%-11s%-15s%-10s%-30s%-10s%-10s%-10s%-10s%n",
					"Product ID", "Name", "Brand", "Category", "Quantity",
					"Specification", "C.P.", "S.P.", "Discount", "Supplied By");
			System.out.printf(
					"%-12s%-27s%-11s%-15s%-10s%-30s%-10s%-10s%-10s%-10s%n",
					"==========", "=========================", "=========",
					"=============", "========", "========================",
					"========", "========", "========", "===========");
			for (Product pr : productList) {
				System.out
						.printf("%-12s%-27s%-11s%-15s%-10s%-30s%-10.1f%-10.1f%-10.1f%-10s%n",
								pr.getProductId(), pr.getName(), pr.getBrand(),
								pr.getCategory(), pr.getQuantity(), pr
										.getSpecification(), pr.getCost(), pr
										.getSellingPrice(), pr.getDiscount(),
								pr.getSupplier().getUserId());
			}
		} catch (Exception e) {
			System.out
					.println(AppConfig.PROPERTIES.getProperty(e.getMessage()));
		}
	}

	public static void showOrdersByUser() {
		String userId = "C101";
		SimpleDateFormat sdf = new SimpleDateFormat("dd-MMM-yyyy");
		try {
			List<Order> orderList = orderService.showOrdersByUser(userId);
			System.out.printf("%-11s%-15s%-12s%-15s%-10s%n", "Order ID",
					"Order Date", "Amount", "No. of Items", "Ordered By");
			System.out.printf("%-11s%-15s%-12s%-15s%-10s%n", "========",
					"============", "=========", "============", "==========");
			for (Order order : orderList) {
				System.out.printf("%-11s%-15s%-12s%-15s%-10s%n", order
						.getOrderId(), sdf.format(order.getOrderDate()
						.getTime()), order.getOrderAmount(), order
						.getNoOfItems(), order.getOrderUser().getUserName());
			}
		} catch (Exception e) {
			System.out
					.println(AppConfig.PROPERTIES.getProperty(e.getMessage()));
		}
	}

	public static void showOrdersByDate() {
		SimpleDateFormat sdf = new SimpleDateFormat("dd-MMM-yyyy");
		try {
			List<Order> orderList = orderService
					.showOrdersByDate(new GregorianCalendar(2015, 3, 10));
			System.out.printf("%-11s%-15s%-12s%-15s%-10s%n", "Order ID",
					"Order Date", "Amount", "No. of Items", "Ordered By");
			System.out.printf("%-11s%-15s%-12s%-15s%-10s%n", "========",
					"============", "=========", "============", "==========");
			for (Order order : orderList) {
				System.out.printf("%-11s%-15s%-12s%-15s%-10s%n", order
						.getOrderId(), sdf.format(order.getOrderDate()
						.getTime()), order.getOrderAmount(), order
						.getNoOfItems(), order.getOrderUser().getUserName());
			}
		} catch (Exception e) {
			System.out
					.println(AppConfig.PROPERTIES.getProperty(e.getMessage()));
		}
	}

	// User Modules Begin

	public static void addUser() {
		User user = new User();
		user.setUserRole(String.valueOf(UserRole.ADMIN));
		user.setUserType(String.valueOf(UserType.GOLD));
		user.setGender(String.valueOf(Gender.FEMALE));
		user.setUserId("A102");
		user.setUserName("Sunnu");
		user.setEmail("sunnu@infy.com");
		user.setMobileNumber("9876543210");
		user.setDateOfBirth(new GregorianCalendar(1997, 10, 6));
		user.setAddress(new Address("12", "Lakshmikanth Nagar", "Mysore",
				"Karnataka", 570027));
		user.setPassword("@sunnu_");
		user.setUserStatus('A');
		try {
			System.out.println(AppConfig.PROPERTIES
					.getProperty("UserInterface.ADD_USER_SUCCESS")
					+ userService.addUser(user));
		} catch (Exception e) {
			e.printStackTrace();
			System.out
					.println(AppConfig.PROPERTIES.getProperty(e.getMessage()));
		}
	}

	public static void updateUser() {
		User user = new User();
		user.setUserType(String.valueOf(UserType.GOLD));
		user.setGender(String.valueOf(Gender.FEMALE));
		user.setUserId("A102");
		user.setUserName("Sunnoo");
		user.setEmail("sunnoo@infy.com");
		user.setMobileNumber("9876543210");
		user.setDateOfBirth(new GregorianCalendar(1997, 10, 6));
		user.setAddress(new Address("13", "Lakshmikanth Nagar", "Mysore",
				"Karnataka", 570027));
		try {
			userService.updateUser(user);
			System.out.println(AppConfig.PROPERTIES
					.getProperty("UserInterface.UPDATE_USER_SUCCESS"));
		} catch (Exception e) {
			System.out
					.println(AppConfig.PROPERTIES.getProperty(e.getMessage()));
		}
	}

	public static void changePassword() {
		String userId = "A102";
		String oldPassword = "@sunnu_";
		String newPassword = "@sunnu$";
		try {
			userService.changePassword(userId, oldPassword, newPassword);
			System.out.println(AppConfig.PROPERTIES
					.getProperty("UserInterface.PASSWORD_CHANGE_SUCCESS"));
		} catch (Exception e) {
			System.out
					.println(AppConfig.PROPERTIES.getProperty(e.getMessage()));
		}
	}

	public static void findUser() {
		String userId = "A102";
		SimpleDateFormat sdf = new SimpleDateFormat("dd-MMM-yyyy");
		try {
			User user = userService.findUser(userId);
			System.out.println("User Details:\n=============");
			System.out.println("User ID: " + user.getUserId());
			System.out.println("Username: " + user.getUserName());
			System.out.println("e-mail: " + user.getEmail());
			System.out.println("Mobile: " + user.getMobileNumber());
			System.out.println("DOB: "
					+ sdf.format(user.getDateOfBirth().getTime()));
			System.out.println("Gender: " + user.getGender());
			System.out.println("Type: " + user.getUserType());
			System.out.println("Role: " + user.getUserRole());
			System.out.println("Address: " + user.getAddress().getDoorNumber()
					+ " " + user.getAddress().getStreet() + " "
					+ user.getAddress().getCity() + " "
					+ user.getAddress().getState() + " "
					+ user.getAddress().getPinCode());
		} catch (Exception e) {
			System.out
					.println(AppConfig.PROPERTIES.getProperty(e.getMessage()));
		}
	}

	public static void deactivateUser() {
		String userId = "C102";
		try {
			userService.deactivateUser(userId);
			System.out.println(AppConfig.PROPERTIES
					.getProperty("UserInterface.DEACTIVATE_USER_SUCCESS"));
		} catch (Exception e) {
			System.out
					.println(AppConfig.PROPERTIES.getProperty(e.getMessage()));
		}
	}

	// Product Modules Begin

	public static void addProduct() {
		Product product = new Product();
		// product.setProductId(1004);
		product.setName("Iphone6+");
		product.setCategory("Mobile");
		product.setBrand("Apple");
		product.setCost(62599.00);
		product.setQuantity(5);
		product.setDiscount(10f);
		product.setSellingPrice(54599.00);
		product.setSpecification("Color:Space Grey;ROM:64GB");
		User user = new User();
		user.setUserId("S101");
		product.setSupplier(user);

		try {
			System.out.println(AppConfig.PROPERTIES
					.getProperty("UserInterface.ADD_PRODUCT_SUCCESS")
					+ productService.addProduct(product));
		} catch (Exception e) {
			System.out
					.println(AppConfig.PROPERTIES.getProperty(e.getMessage()));
		}
	}

	public static void updateProduct() {
		Product product = new Product();
		product.setProductId(1000);

		User user = new User();
		user.setUserId("C101");
		product.setSupplier(user);
		try {
			productService.updateProduct(product);
			System.out.println(AppConfig.PROPERTIES
					.getProperty("UserInterface.UPDATE_PRODUCT_SUCCESS"));
		} catch (Exception e) {
			System.out
					.println(AppConfig.PROPERTIES.getProperty(e.getMessage()));
		}
	}

	public static void deleteProduct() {
		Integer productId = 1002;
		try {
			productService.deleteProduct(productId);
			System.out.println(AppConfig.PROPERTIES
					.getProperty("UserInterface.DELETE_PRODUCT_SUCCESS"));
		} catch (Exception e) {
			System.out
					.println(AppConfig.PROPERTIES.getProperty(e.getMessage()));
		}
	}

	public static void getProductDetails() {
		Integer productId = 1000;
		try {
			Product product = productService.getProductDetails(productId);
			System.out.println("Product Details:");
			System.out.println("-----------------");
			System.out.println("Product ID: " + product.getProductId());
			System.out.println("Name: " + product.getName());
			System.out.println("Cost Price: " + product.getCost());
			System.out.println("Selling Price: " + product.getSellingPrice());
			System.out.println("Quantity: " + product.getQuantity());
			System.out.println("Specification: " + product.getSpecification());
		} catch (Exception e) {
			System.out
					.println(AppConfig.PROPERTIES.getProperty(e.getMessage()));
		}
	}

	// order module
	public static void placeOrder() {
		Order order = new Order();
		User user = new User();
		user.setUserId("C101");
		order.setOrderUser(user);
		order.setOrderProducts(new HashSet<OrderProduct>());
		order.getOrderProducts().add(new OrderProduct(1000, 1));
		order.getOrderProducts().add(new OrderProduct(1001, 3));
		try {
			System.out.println(AppConfig.PROPERTIES
					.getProperty("UserInterface.ORDER_SUCCESS")
					+ orderService.placeOrder(order));
			System.out.println("Number of Items: " + order.getNoOfItems());
			System.out.println("Order Amount: " + order.getOrderAmount());
			System.out.println("Order placed by: " + order.getOrderType());
		} catch (Exception e) {
			e.printStackTrace();
			System.out
					.println(AppConfig.PROPERTIES.getProperty(e.getMessage()));
		}
	}

	public static void viewOrder() {
		Integer orderId = 1000;
		SimpleDateFormat sdf = new SimpleDateFormat("dd-MMM-yyyy");
		try {
			Order order = orderService.viewOrder(orderId);
			System.out.println("Order ID: " + order.getOrderId());
			System.out.println("Order Date: "
					+ sdf.format(order.getOrderDate().getTime()));
			System.out.println("Amount: " + order.getOrderAmount());
			System.out.println("No. of Items: " + order.getNoOfItems());
			System.out.println("Order Type: " + order.getOrderType());
			System.out.println("Ordered By: "
					+ order.getOrderUser().getUserId() + "\tUserName:"
					+ order.getOrderUser().getUserName());
		} catch (Exception e) {
			System.out
					.println(AppConfig.PROPERTIES.getProperty(e.getMessage()));
		}
	}

	public static void getOrderProductDetails() {
		Integer orderId = 1000;
		Integer productId = 1000;
		try {
			Integer quantity = orderService.getOrderProductDetails(orderId,
					productId);
			System.out.println("Order ID: " + orderId);
			System.out.println("Product ID: " + productId);
			System.out.println("Quantity: " + quantity);

		} catch (Exception e) {
			System.out
					.println(AppConfig.PROPERTIES.getProperty(e.getMessage()));
		}
	}

}
