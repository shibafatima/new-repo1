package com.infy.infyretailapp.test;

import java.util.ArrayList;
import java.util.List;

import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;

import com.infy.infyretailapp.bean.Offers;
import com.infy.infyretailapp.bean.RetailOutlet;
import com.infy.infyretailapp.business.service.RetailOfferService;
import com.infy.infyretailapp.resources.Factory;

public class RetailOfferServiceTest {

	@Rule
	public ExpectedException expectedException = ExpectedException.none();

	@Test
	public void inValidOffers() throws Exception {

		expectedException.expectMessage("Service.INVALID_OFFERS");

		RetailOfferService service = Factory.createRetailOfferService();
		Integer retailOutletId = 5005;
		String retailOutletName = "Infy Levis";
		String city = "Chennai";
		List<Offers> offers = new ArrayList<Offers>();
		Offers obj = new Offers();
		obj.setOfferId(2020);

		offers.add(obj);

		RetailOutlet retailOutlet = new RetailOutlet();
		retailOutlet.setRetailOutletId(retailOutletId);
		retailOutlet.setRetailOutletName(retailOutletName);
		retailOutlet.setCity(city);
		retailOutlet.setOffers(offers);

		service.addRetailOutletAndExistingOffer(retailOutlet);

	}

}
