package com.infy.infyretailapp.resources;

import com.infy.infyretailapp.business.service.LoginServiceImpl;
import com.infy.infyretailapp.business.service.OrderServiceImpl;
import com.infy.infyretailapp.business.service.ProductServiceImpl;
import com.infy.infyretailapp.business.service.RetailOfferServiceImpl;
import com.infy.infyretailapp.business.service.UserServiceImpl;
import com.infy.infyretailapp.dao.LoginDAOImpl;
import com.infy.infyretailapp.dao.OrderDAOImpl;
import com.infy.infyretailapp.dao.ProductDAOImpl;
import com.infy.infyretailapp.dao.RetailOfferDAOImpl;
import com.infy.infyretailapp.dao.UserDAOImpl;

public class Factory {
	public static UserServiceImpl createUserService() {
		return new UserServiceImpl();
	}

	public static UserDAOImpl createUserDAO() {
		return new UserDAOImpl();
	}

	public static ProductServiceImpl createProductService() {
		return new ProductServiceImpl();
	}

	public static ProductDAOImpl createProductDAO() {
		return new ProductDAOImpl();
	}

	public static OrderServiceImpl createOrderService() {
		return new OrderServiceImpl();
	}

	public static OrderDAOImpl createOrderDAO() {
		return new OrderDAOImpl();
	}

	public static RetailOfferServiceImpl createRetailOfferService() {

		return new RetailOfferServiceImpl();
	}

	public static RetailOfferDAOImpl createRetailOfferDao() {

		return new RetailOfferDAOImpl();
	}

	public static LoginServiceImpl createLoginService() {

		return new LoginServiceImpl();
	}

	public static LoginDAOImpl createLoginDAO() {

		return new LoginDAOImpl();
	}
}