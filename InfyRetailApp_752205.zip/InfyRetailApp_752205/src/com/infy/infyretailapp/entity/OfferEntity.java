package com.infy.infyretailapp.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "INFYRETAIL_OFFERS")
public class OfferEntity {

	@Id
	@Column(name = "offer_id")
	private Integer offerId;
	@Column(name = "offer_name")
	private String offerName;
	@Column(name = "offer_month")
	private String offerMonth;

	public Integer getOfferId() {
		return offerId;
	}

	public void setOfferId(Integer offerId) {
		this.offerId = offerId;
	}

	public String getOfferName() {
		return offerName;
	}

	public void setOfferName(String offerName) {
		this.offerName = offerName;
	}

	public String getOfferMonth() {
		return offerMonth;
	}

	public void setOfferMonth(String offerMonth) {
		this.offerMonth = offerMonth;
	}

}
