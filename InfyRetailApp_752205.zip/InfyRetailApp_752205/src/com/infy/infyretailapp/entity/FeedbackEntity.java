package com.infy.infyretailapp.entity;

import java.util.Calendar;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="INFYRETAIL_FEEDBACK")
public class FeedbackEntity {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "FEEDBACK_ID")
	private Integer feedbackId;
	@Column(name = "USER_ID")
	private String userId;
	@Column(name="PRODUCT_ID")
	private Integer productId;
	private String description;
	private String rating;
	@Column(name = "FEEDBACK_DATE")
	private Calendar feedbackDate;
	
	
	public Integer getProductId() {
		return productId;
	}
	public void setProductId(Integer productId) {
		this.productId = productId;
	}
	public void setRating(String rating) {
		this.rating = rating;
	}
	public Integer getFeedbackId() {
		return feedbackId;
	}
	public void setFeedbackId(Integer feedbackId) {
		this.feedbackId = feedbackId;
	}
	public String getRating() {
		return rating;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	
	public Calendar getFeedbackDate() {
		return feedbackDate;
	}
	public void setFeedbackDate(Calendar feedbackDate) {
		this.feedbackDate = feedbackDate;
	}

	
}
