package com.infy.infyretailapp.entity;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.TableGenerator;

@Entity
@Table(name = "infyretail_product")
@TableGenerator(name = "ProductIdPkey", table = "DB_ProductIdPkeyTable", pkColumnName = "ProductIdPrimaryKey", pkColumnValue = "productId", valueColumnName = "NextValue", allocationSize = 1)
public class ProductEntity {
	@Id
	@GeneratedValue(strategy = GenerationType.TABLE, generator = "ProductIdPkey")
	@Column(name = "product_id")
	private Integer productId;
	@Column(name = "product_name")
	private String name;
	@Column(name = "product_category")
	private String category;
	@Column(name = "product_brand")
	private String brand;
	@Column(name = "product_cost")
	private Double cost;
	@Column(name = "product_quantity")
	private Integer quantity;
	@Column(name = "product_discount")
	private Float discount;
	@Column(name = "product_sellingprice")
	private Double sellingPrice;
	@Column(name = "product_specification")
	private String specification;
	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "PRODUCT_SUPPLIER_ID")
	private UserEntity supplier;

	public UserEntity getSupplier() {
		return supplier;
	}

	public void setSupplier(UserEntity supplier) {
		this.supplier = supplier;
	}

	public Integer getProductId() {
		return productId;
	}

	public void setProductId(Integer productId) {
		this.productId = productId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public String getBrand() {
		return brand;
	}

	public void setBrand(String brand) {
		this.brand = brand;
	}

	public Double getCost() {
		return cost;
	}

	public void setCost(Double cost) {
		this.cost = cost;
	}

	public Integer getQuantity() {
		return quantity;
	}

	public void setQuantity(Integer quantity) {
		this.quantity = quantity;
	}

	public Float getDiscount() {
		return discount;
	}

	public void setDiscount(Float discount) {
		this.discount = discount;
	}

	public Double getSellingPrice() {
		return sellingPrice;
	}

	public void setSellingPrice(Double sellingPrice) {
		this.sellingPrice = sellingPrice;
	}

	public String getSpecification() {
		return specification;
	}

	public void setSpecification(String specification) {
		this.specification = specification;
	}

}
