package com.infy.infyretailapp.entity;

import java.util.Calendar;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "infyretail_order")
public class OrderEntity {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "order_id")
	private Integer orderId;
	@Column(name = "order_date")
	private Calendar orderDate;
	@Column(name = "order_amount")
	private Double orderAmount;
	@Column(name = "no_of_items")
	private Integer noOfItems;
	@Column(name = "order_type")
	private String orderType;
	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "ORDER_USER_ID")
	private UserEntity orderUser;

	public Integer getOrderId() {
		return orderId;
	}

	public void setOrderId(Integer orderId) {
		this.orderId = orderId;
	}

	public Calendar getOrderDate() {
		return orderDate;
	}

	public void setOrderDate(Calendar orderDate) {
		this.orderDate = orderDate;
	}

	public Double getOrderAmount() {
		return orderAmount;
	}

	public void setOrderAmount(Double orderAmount) {
		this.orderAmount = orderAmount;
	}

	public Integer getNoOfItems() {
		return noOfItems;
	}

	public void setNoOfItems(Integer noOfItems) {
		this.noOfItems = noOfItems;
	}

	public String getOrderType() {
		return orderType;
	}

	public void setOrderType(String orderType) {
		this.orderType = orderType;
	}

	public UserEntity getOrderUser() {
		return orderUser;
	}

	public void setOrderUser(UserEntity orderUser) {
		this.orderUser = orderUser;
	}

}
