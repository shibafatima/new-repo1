package com.infy.infyretailapp.entity;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;
import javax.persistence.JoinColumn;

@Entity
@Table(name = "INFYRETAIL_RETAILOUTLET")
public class RetailOutletEntity {
	@Id
	@Column(name = "retailoutlet_id")
	private Integer retailOutletId;
	@Column(name = "retailoutlet_name")
	private String retailOutletName;
	@Column(name = "city")
	private String city;

	@ManyToMany(cascade = CascadeType.ALL)
	@JoinTable(name = "INFYRETAIL_RETAILOUTLET_OFFER", joinColumns = @JoinColumn(name = "retailOutlet_Id", referencedColumnName = "retailoutlet_Id"), inverseJoinColumns = @JoinColumn(name = "offer_Id", referencedColumnName = "offer_id"))
	private List<OfferEntity> offers;

	public Integer getRetailOutletId() {
		return retailOutletId;
	}

	public List<OfferEntity> getOffers() {
		return offers;
	}

	public void setOffers(List<OfferEntity> offers) {
		this.offers = offers;
	}

	public void setRetailOutletId(Integer retailOutletId) {
		this.retailOutletId = retailOutletId;
	}

	public String getRetailOutletName() {
		return retailOutletName;
	}

	public void setRetailOutletName(String retailOutletName) {
		this.retailOutletName = retailOutletName;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

}
