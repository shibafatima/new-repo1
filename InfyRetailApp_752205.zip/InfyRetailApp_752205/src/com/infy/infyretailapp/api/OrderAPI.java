package com.infy.infyretailapp.api;

import java.util.HashSet;
import java.util.List;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

import com.infy.infyretailapp.bean.Order;
import com.infy.infyretailapp.bean.OrderProduct;
import com.infy.infyretailapp.bean.Product;
import com.infy.infyretailapp.bean.User;
import com.infy.infyretailapp.business.service.OrderService;
import com.infy.infyretailapp.resources.AppConfig;
import com.infy.infyretailapp.resources.Factory;
import com.infy.infyretailapp.resources.JSONParser;

@Path("OrderAPI")
public class OrderAPI {

	// order is placed by an user
	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public Response placeOrder(String dataRecieved,
			@Context HttpServletRequest request) throws Exception {
		Response response = null;

		Product product = JSONParser.fromJson(dataRecieved, Product.class);
		try {
			Order order = new Order();
			User user = new User();
			String userId = null;
			Cookie[] cookies = request.getCookies();
			for (Cookie cookie : cookies) {
				if (cookie.getName().equals(
						AppConfig.PROPERTIES.getProperty("Cookie.NAME_ID"))) {
					userId = cookie.getValue().toString();
				}
			}
			user.setUserId(userId);
			order.setOrderUser(user);
			order.setOrderProducts(new HashSet<OrderProduct>());
			order.getOrderProducts().add(
					new OrderProduct(product.getProductId(), product
							.getQuantity()));
			OrderService orderService = Factory.createOrderService();
			Integer productId = orderService.placeOrder(order);
			String message = AppConfig.PROPERTIES
					.getProperty("OrderAPI.SUCCESSFUL_ORDER");
			message += productId;
			Order beanForMessage = new Order();
			beanForMessage.setMessage(message);
			String returnString = JSONParser.toJson(beanForMessage);

			response = Response.status(Status.OK).entity(returnString).build();
		} catch (Exception e) {
			Order beanForMessage = new Order();
			beanForMessage.setMessage(AppConfig.PROPERTIES.getProperty(e
					.getMessage()));
			String returnString = JSONParser.toJson(beanForMessage);
			if (e.getMessage().contains("DAO")) {
				response = Response.status(Status.SERVICE_UNAVAILABLE)
						.entity(returnString).build();
			} else {
				response = Response.status(Status.BAD_REQUEST)
						.entity(returnString).build();
			}

		}

		return response;
	}

	// displays all the order from the database
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public Response showAllOrders() throws Exception {

		Response response = null;
		try {

			OrderService orderService = Factory.createOrderService();
			List<Order> allOrderList = orderService.showAllOrders();

			if (allOrderList.size() == 0) {
				String message = AppConfig.PROPERTIES
						.getProperty("OrderAPI.NO_ORDERS_PLACED");

				Order beanForMessage = new Order();
				beanForMessage.setMessage(message);
				String returnString = JSONParser.toJson(beanForMessage);
				response = Response.status(Status.BAD_REQUEST)
						.entity(returnString).build();
			} else {
				String returnString = JSONParser.toJson(allOrderList);
				response = Response.ok(returnString).build();
			}
		} catch (Exception e) {
			e.printStackTrace();
			Order beanForMessage = new Order();
			beanForMessage.setMessage(AppConfig.PROPERTIES.getProperty(e
					.getMessage()));
			String returnString = JSONParser.toJson(beanForMessage);
			if (e.getMessage().contains("DAO")) {
				response = Response.status(Status.SERVICE_UNAVAILABLE)
						.entity(returnString).build();
			} else {
				response = Response.status(Status.BAD_REQUEST)
						.entity(returnString).build();
			}
		}

		return response;
	}

	// show the order details of a particular user
	@GET
	@Path("ordersByUser")
	@Produces(MediaType.APPLICATION_JSON)
	public Response showOrdersByUser(@Context HttpServletRequest request)
			throws Exception {

		Response response = null;
		try {
			String userId = null;
			Cookie[] cookies = request.getCookies();
			for (Cookie cookie : cookies) {
				if (cookie.getName().equals(
						AppConfig.PROPERTIES.getProperty("Cookie.NAME_ID"))) {
					userId = cookie.getValue().toString();
				}
			}
			OrderService orderService = Factory.createOrderService();

			List<Order> orderList = orderService.showOrdersByUser(userId);

			if (orderList.size() == 0) {
				String message = AppConfig.PROPERTIES
						.getProperty("OrderAPI.NO_ORDERS_PLACED_BY_CUSTOMER");
				Order beanForMessage = new Order();
				beanForMessage.setMessage(message);
				String returnString = JSONParser.toJson(beanForMessage);

				response = Response.status(Status.BAD_REQUEST)
						.entity(returnString).build();

			} else {
				String returnString = JSONParser.toJson(orderList);
				response = Response.ok(returnString).build();
			}
		} catch (Exception e) {
			Order beanForMessage = new Order();
			beanForMessage.setMessage(AppConfig.PROPERTIES.getProperty(e
					.getMessage()));
			String returnString = JSONParser.toJson(beanForMessage);
			if (e.getMessage().contains("DAO")) {
				response = Response.status(Status.SERVICE_UNAVAILABLE)
						.entity(returnString).build();
			} else {
				response = Response.status(Status.BAD_REQUEST)
						.entity(returnString).build();
			}
		}

		return response;
	}
	
	@GET
	@Path("getProductNamesOrderedByUserId")
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public Response getProductNamesOrderedByUserId(@Context HttpServletRequest request)
			throws Exception {
		Response response = null;
		try {
			String userId = null;
			Cookie[] cookies = request.getCookies();
			for (Cookie cookie : cookies) {
				if (cookie.getName().equals(
						AppConfig.PROPERTIES.getProperty("Cookie.NAME_ID"))) {
					userId = cookie.getValue().toString();
				}
			}
			
			List<Product> productList = Factory.createOrderService().getProductNamesOrderedByUserId(userId);
			String returnString = JSONParser.toJson(productList);
			response = Response.ok(returnString).build();
		}
		catch (Exception e) {
			e.printStackTrace();
			Order beanForMessage = new Order();
			beanForMessage.setMessage(AppConfig.PROPERTIES.getProperty(e
					.getMessage()));
			String returnString = JSONParser.toJson(beanForMessage);
			if (e.getMessage().contains("DAO")) {
				response = Response.status(Status.SERVICE_UNAVAILABLE)
						.entity(returnString).build();
			} else {
				response = Response.status(Status.BAD_REQUEST)
						.entity(returnString).build();
			}
		}
		return response;
	}
}
