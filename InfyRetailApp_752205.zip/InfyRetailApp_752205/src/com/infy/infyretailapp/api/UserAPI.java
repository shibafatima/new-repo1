package com.infy.infyretailapp.api;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

import com.infy.infyretailapp.bean.Feedback;
import com.infy.infyretailapp.bean.User;
import com.infy.infyretailapp.business.service.ProductService;
import com.infy.infyretailapp.business.service.UserService;
import com.infy.infyretailapp.resources.AppConfig;
import com.infy.infyretailapp.resources.Factory;
import com.infy.infyretailapp.resources.JSONParser;

@Path("UserAPI")
public class UserAPI {

	@POST
	@Path("submitFeedback")
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public Response submitFeedback(@Context HttpServletRequest request, String dataRecieved)
			throws Exception {
		Response response = null;
		try {
			String userId = null;
			Cookie[] cookies = request.getCookies();
			for (Cookie cookie : cookies) {
				if (cookie.getName().equals(
						AppConfig.PROPERTIES.getProperty("Cookie.NAME_ID"))) {
					userId = cookie.getValue().toString();
				}
			}
			Feedback feedback = JSONParser.fromJson(dataRecieved, Feedback.class);
			feedback.setUserId(userId);
			
			Integer feedbackId = Factory.createUserService().submitFeedback(feedback);
			String message =AppConfig.PROPERTIES.getProperty("UserAPI.FEEDBACK_SUBMITTED_SUCCESSFULLY")+feedbackId;
			feedback.setMessage(message);

			String returnString = JSONParser.toJson(feedback);
			response = Response.ok(returnString).build();

		} catch (Exception e) {
			Feedback beanForMessage = new Feedback();
			beanForMessage.setMessage(AppConfig.PROPERTIES.getProperty(e
					.getMessage()));
			String returnString = JSONParser.toJson(beanForMessage);
			if (e.getMessage().contains("DAO")) {
				response = Response.status(Status.SERVICE_UNAVAILABLE)
						.entity(returnString).build();
			} else {
				response = Response.status(Status.BAD_REQUEST)
						.entity(returnString).build();
			}
		}
		return response;
	}
	
	// change the status of a particular user to deactive
	@POST
	@Path("deactivateUser")
	@Produces(MediaType.APPLICATION_JSON)
	public Response deactivateUser(String userId) throws Exception {
		Response response = null;
		try {

			UserService userService = Factory.createUserService();
			userService.deactivateUser(userId);

			User beanForMessage = new User();
			beanForMessage.setMessage(AppConfig.PROPERTIES
					.getProperty("UserAPI.SUCCESSFUL_DEACTIVATION"));
			String returnString = JSONParser.toJson(beanForMessage);

			response = Response.ok(returnString).build();
		} catch (Exception e) {

			User beanForMessage = new User();
			beanForMessage.setMessage(AppConfig.PROPERTIES.getProperty(e
					.getMessage()));
			String returnString = JSONParser.toJson(beanForMessage);
			if (e.getMessage().contains("DAO")) {
				response = Response.status(Status.SERVICE_UNAVAILABLE)
						.entity(returnString).build();
			} else {
				response = Response.status(Status.BAD_REQUEST)
						.entity(returnString).build();
			}

		}

		return response;
	}

	// fetches the user id of user whose status is supplier
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public Response getSupplierIdList() throws Exception {
		Response response = null;
		try {
			ProductService productService = Factory.createProductService();
			List<String> suplierIdList = productService.getSupplierIdList();
			String returnString = JSONParser.toJson(suplierIdList);

			response = Response.ok(returnString).build();
		} catch (Exception e) {

			User beanForMessage = new User();
			beanForMessage.setMessage(AppConfig.PROPERTIES.getProperty(e
					.getMessage()));
			String returnString = JSONParser.toJson(beanForMessage);
			if (e.getMessage().contains("DAO")) {
				response = Response.status(Status.SERVICE_UNAVAILABLE)
						.entity(returnString).build();
			} else {
				response = Response.status(Status.BAD_REQUEST)
						.entity(returnString).build();
			}

		}
		return response;
	}

	
	@GET
	@Path("getAllFeedback")
	@Produces(MediaType.APPLICATION_JSON)
	public Response getAllFeedback() throws Exception {
		Response response = null;
		try{
			UserService service = Factory.createUserService();
			List<Feedback> feedback = service.getAllFeedback();
			String returnString = JSONParser.toJson(feedback);
			response = Response.ok(returnString).build();
		}
		
		catch (Exception e) {

			User beanForMessage = new User();
			beanForMessage.setMessage(AppConfig.PROPERTIES.getProperty(e
					.getMessage()));
			String returnString = JSONParser.toJson(beanForMessage);
			if (e.getMessage().contains("DAO")) {
				response = Response.status(Status.SERVICE_UNAVAILABLE)
						.entity(returnString).build();
			} else {
				response = Response.status(Status.BAD_REQUEST)
						.entity(returnString).build();
			}

		}
		return response;
	}
	
	
	
	
	// fetches userId of all the users from the database
	@GET
	@Path("userIdList")
	@Produces(MediaType.APPLICATION_JSON)
	public Response generateUserIdList() throws Exception {
		Response response = null;
		try {

			UserService service = Factory.createUserService();
			List<User> userList = service.getOnlyUsers();
			List<String> userIdList = new ArrayList<String>();
			for (User user : userList) {
				userIdList.add(user.getUserId());
			}
			String returnString = JSONParser.toJson(userIdList);

			response = Response.ok(returnString).build();
		} catch (Exception e) {

			User beanForMessage = new User();
			beanForMessage.setMessage(AppConfig.PROPERTIES.getProperty(e
					.getMessage()));
			String returnString = JSONParser.toJson(beanForMessage);
			if (e.getMessage().contains("DAO")) {
				response = Response.status(Status.SERVICE_UNAVAILABLE)
						.entity(returnString).build();
			} else {
				response = Response.status(Status.BAD_REQUEST)
						.entity(returnString).build();
			}

		}

		return response;
	}

	// fetches all the details of users from the database
	@GET
	@Path("userList")
	@Produces(MediaType.APPLICATION_JSON)
	public Response generateUserList() throws Exception {
		Response response = null;
		try {
			UserService service = Factory.createUserService();
			List<User> userList = service.getOnlyUsers();

			String returnString = JSONParser.toJson(userList);

			response = Response.ok(returnString).build();
		} catch (Exception e) {

			User beanForMessage = new User();
			beanForMessage.setMessage(AppConfig.PROPERTIES.getProperty(e
					.getMessage()));
			String returnString = JSONParser.toJson(beanForMessage);
			if (e.getMessage().contains("DAO")) {
				response = Response.status(Status.SERVICE_UNAVAILABLE)
						.entity(returnString).build();
			} else {
				response = Response.status(Status.BAD_REQUEST)
						.entity(returnString).build();
			}

		}

		return response;
	}

	// get the details of the user by getting the userid from cookies
	@GET
	@Path("userDetailsById")
	@Produces(MediaType.APPLICATION_JSON)
	public Response getUserDetailsById(@Context HttpServletRequest request)
			throws Exception {
		Response response = null;
		UserService userService = Factory.createUserService();
		try {
			String userId = null;
			Cookie[] cookies = request.getCookies();
			for (Cookie cookie : cookies) {
				if (cookie.getName().equals(
						AppConfig.PROPERTIES.getProperty("Cookie.NAME_ID"))) {
					userId = cookie.getValue().toString();
				}
			}
			User user = userService.findUser(userId);

			String returnString = JSONParser.toJson(user);

			response = Response.ok(returnString).build();

		} catch (Exception e) {

			User beanForMessage = new User();
			beanForMessage.setMessage(AppConfig.PROPERTIES.getProperty(e
					.getMessage()));
			String returnString = JSONParser.toJson(beanForMessage);
			if (e.getMessage().contains("DAO")) {
				response = Response.status(Status.SERVICE_UNAVAILABLE)
						.entity(returnString).build();
			} else {
				response = Response.status(Status.BAD_REQUEST)
						.entity(returnString).build();
			}

		}
		return response;
	}

	// update the mail id and phone number of the user in the database
	@PUT
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public Response updateUserDetails(String dataRecieved) throws Exception {
		Response response = null;
		User user = JSONParser.fromJson(dataRecieved, User.class);
		try {
			UserService service = Factory.createUserService();
			service.updateUserDetails(user);
			String message = AppConfig.PROPERTIES
					.getProperty("UserInterface.UPDATE_USER_SUCCESS");
			User beanForMessage = new User();
			beanForMessage.setMessage(message);
			String returnString = JSONParser.toJson(beanForMessage);

			response = Response.status(Status.OK).entity(returnString).build();

		} catch (Exception e) {

			User beanForMessage = new User();
			beanForMessage.setMessage(AppConfig.PROPERTIES.getProperty(e
					.getMessage()));
			String returnString = JSONParser.toJson(beanForMessage);
			if (e.getMessage().contains("DAO")) {
				response = Response.status(Status.SERVICE_UNAVAILABLE)
						.entity(returnString).build();
			} else {
				response = Response.status(Status.BAD_REQUEST)
						.entity(returnString).build();
			}
		}

		return response;
	}

	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public Response getUserDetailsForAdmin(String dataRecieved)
			throws Exception {
		Response response = null;
		User user = JSONParser.fromJson(dataRecieved, User.class);
		try {
			UserService userService = Factory.createUserService();
			User reterivedUserInformation = userService.findUser(user
					.getUserId());

			String returnString = JSONParser.toJson(reterivedUserInformation);

			response = Response.ok(returnString).build();

		} catch (Exception e) {

			User beanForMessage = new User();
			beanForMessage.setMessage(AppConfig.PROPERTIES.getProperty(e
					.getMessage()));
			String returnString = JSONParser.toJson(beanForMessage);
			if (e.getMessage().contains("DAO")) {
				response = Response.status(Status.SERVICE_UNAVAILABLE)
						.entity(returnString).build();
			} else {
				response = Response.status(Status.BAD_REQUEST)
						.entity(returnString).build();
			}
		}

		return response;
	}
}
