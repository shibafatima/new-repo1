package com.infy.infyretailapp.api;

import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

import com.infy.infyretailapp.bean.User;
import com.infy.infyretailapp.business.service.LoginService;
import com.infy.infyretailapp.resources.AppConfig;
import com.infy.infyretailapp.resources.Factory;
import com.infy.infyretailapp.resources.JSONParser;

@Path("LoginAPI")
public class LoginAPI {
	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public Response getUserDetails(String dataRecieved) throws Exception {
		Response response = null;

		User user = JSONParser.fromJson(dataRecieved, User.class);
		try {
			LoginService loginService = Factory.createLoginService();
			User reterivedUserInformation = loginService.getUserDetails(
					user.getUserName(), user.getPassword());

			String returnString = JSONParser.toJson(reterivedUserInformation);

			response = Response.ok(returnString).build();
		} catch (Exception e) {
			User beanForMessage = new User();
			beanForMessage.setMessage(AppConfig.PROPERTIES.getProperty(e
					.getMessage()));
			String returnString = JSONParser.toJson(beanForMessage);
			if (e.getMessage().contains("DAO")) {
				response = Response.status(Status.SERVICE_UNAVAILABLE)
						.entity(returnString).build();
			} else {
				response = Response.status(Status.BAD_REQUEST)
						.entity(returnString).build();
			}
		}
		return response;
	}

}
