package com.infy.infyretailapp.api;

import java.util.ArrayList;
import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

import com.infy.infyretailapp.bean.Product;
import com.infy.infyretailapp.business.service.ProductService;
import com.infy.infyretailapp.resources.AppConfig;
import com.infy.infyretailapp.resources.Factory;
import com.infy.infyretailapp.resources.JSONParser;

@Path("ProductAPI")
public class ProductAPI {
	// fetches ProductId all the Products from the database
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public Response generateProductIdList() throws Exception {
		Response response = null;
		try {
			ProductService productService = Factory.createProductService();

			List<Product> productList = productService.getAllProducts();
			List<Integer> productIdList = new ArrayList<Integer>();
			for (Product product : productList) {
				productIdList.add(product.getProductId());
			}
			String returnString = JSONParser.toJson(productIdList);
			response = Response.ok(returnString).build();
		} catch (Exception e) {

			Product beanForMessage = new Product();
			beanForMessage.setMessage(AppConfig.PROPERTIES.getProperty(e
					.getMessage()));
			String returnString = JSONParser.toJson(beanForMessage);
			if (e.getMessage().contains("DAO")) {
				response = Response.status(Status.SERVICE_UNAVAILABLE)
						.entity(returnString).build();
			} else {
				response = Response.status(Status.BAD_REQUEST)
						.entity(returnString).build();

			}
		}

		return response;
	}

	// fetches the category of products
	@GET
	@Path("category")
	@Produces(MediaType.APPLICATION_JSON)
	public Response getCategoryDetails() throws Exception {
		Response response = null;
		try {
			ProductService productService = Factory.createProductService();
			List<String> categoryList = productService.getCategoryDetails();

			String returnString = JSONParser.toJson(categoryList);
			response = Response.ok(returnString).build();
		} catch (Exception e) {

			Product beanForMessage = new Product();
			beanForMessage.setMessage(AppConfig.PROPERTIES.getProperty(e
					.getMessage()));
			String returnString = JSONParser.toJson(beanForMessage);
			if (e.getMessage().contains("DAO")) {
				response = Response.status(Status.SERVICE_UNAVAILABLE)
						.entity(returnString).build();
			} else {
				response = Response.status(Status.BAD_REQUEST)
						.entity(returnString).build();

			}
		}
		return response;
	}

	// fetches all the details of all the products from the database
	@GET
	@Path("allProductsList")
	@Produces(MediaType.APPLICATION_JSON)
	public Response getAllProductsList() throws Exception {
		Response response = null;

		try {
			ProductService productService = Factory.createProductService();
			List<Product> productList = productService.getAllProducts();
			String returnString = JSONParser.toJson(productList);
			response = Response.ok(returnString).build();
		} catch (Exception e) {

			Product beanForMessage = new Product();
			beanForMessage.setMessage(AppConfig.PROPERTIES.getProperty(e
					.getMessage()));
			String returnString = JSONParser.toJson(beanForMessage);
			if (e.getMessage().contains("DAO")) {
				response = Response.status(Status.SERVICE_UNAVAILABLE)
						.entity(returnString).build();
			} else {
				response = Response.status(Status.BAD_REQUEST)
						.entity(returnString).build();

			}
		}

		return response;
	}

	// Adds a new product to the database
	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public Response addProduct(String dataRecieved) throws Exception {
		Response response = null;

		Product product = JSONParser.fromJson(dataRecieved, Product.class);
		try {
			ProductService productService = Factory.createProductService();
			Integer productId = productService.addProduct(product);
			String message = AppConfig.PROPERTIES
					.getProperty("ProductAPI.ADD_PRODUCT_SUCCESS_PART1");
			message += productId;
			Product beanForMessage = new Product();
			beanForMessage.setMessage(message);
			String returnString = JSONParser.toJson(beanForMessage);
			response = Response.status(Status.OK).entity(returnString).build();

		} catch (Exception e) {

			Product beanForMessage = new Product();
			beanForMessage.setMessage(AppConfig.PROPERTIES.getProperty(e
					.getMessage()));
			String returnString = JSONParser.toJson(beanForMessage);
			if (e.getMessage().contains("DAO")) {
				response = Response.status(Status.SERVICE_UNAVAILABLE)
						.entity(returnString).build();
			} else {
				response = Response.status(Status.BAD_REQUEST)
						.entity(returnString).build();

			}
		}

		return response;
	}

	// Deletes a product from the database
	@DELETE
	@Path("{productId}")
	@Produces(MediaType.APPLICATION_JSON)
	public Response deleteProduct(@PathParam("productId") int productId)
			throws Exception {
		Response response = null;

		try {
			ProductService productService = Factory.createProductService();
			productService.deleteProduct(productId);

			String returnString = "success";
			response = Response.ok(returnString).build();

		} catch (Exception e) {

			Product beanForMessage = new Product();
			beanForMessage.setMessage(AppConfig.PROPERTIES.getProperty(e
					.getMessage()));
			String returnString = JSONParser.toJson(beanForMessage);
			if (e.getMessage().contains("DAO")) {
				response = Response.status(Status.SERVICE_UNAVAILABLE)
						.entity(returnString).build();
			} else {
				response = Response.status(Status.BAD_REQUEST)
						.entity(returnString).build();

			}
		}

		return response;
	}

	// Gets all the details of the products based on the price range passed
	@POST
	@Path("productsInPriceRange")
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public Response getProductsInPriceRange(String dataRecieved)
			throws Exception {

		Response response = null;
		Product product = new Product();
		product = JSONParser.fromJson(dataRecieved, Product.class);
		try {
			if (product == null) {
				String message = AppConfig.PROPERTIES
						.getProperty("ProductAPI.INVALID_RANGE");
				Product beanForMessage = new Product();
				beanForMessage.setMessage(message);
				String returnString = JSONParser.toJson(beanForMessage);
				response = Response.status(Status.BAD_REQUEST)
						.entity(returnString).build();
			} else {

				ProductService productService = Factory.createProductService();
				String rangereturnStrings[] = product.getRange().split("-");

				double lowerBound = Double.parseDouble(rangereturnStrings[0]);
				double upperBound = Double.parseDouble(rangereturnStrings[1]);
				List<Product> productList = productService
						.getProductsInPriceRange(lowerBound, upperBound);

				String returnString = JSONParser.toJson(productList);

				response = Response.ok(returnString).build();
			}

		} catch (Exception e) {

			Product beanForMessage = new Product();
			beanForMessage.setMessage(AppConfig.PROPERTIES.getProperty(e
					.getMessage()));
			String returnString = JSONParser.toJson(beanForMessage);
			if (e.getMessage().contains("DAO")) {
				response = Response.status(Status.SERVICE_UNAVAILABLE)
						.entity(returnString).build();
			} else {
				response = Response.status(Status.BAD_REQUEST)
						.entity(returnString).build();

			}
		}

		return response;
	}

	// Get details of all the products based on Id
	@POST
	@Path("productDetailsById")
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public Response getProductDetailsById(String dataRecieved) throws Exception {
		Product product = new Product();

		Response response = null;
		product = JSONParser.fromJson(dataRecieved, Product.class);
		try {
			if (product == null) {

				String message = AppConfig.PROPERTIES
						.getProperty("ProductDetailsBean.INVALID_PRODUCTID");
				Product beanForMessage = new Product();
				beanForMessage.setMessage(message);
				String returnString = JSONParser.toJson(beanForMessage);
				response = Response.status(Status.BAD_REQUEST)
						.entity(returnString).build();

			} else {

				ProductService productService = Factory.createProductService();
				Product product2 = productService.getProductDetails(product
						.getProductId());

				String returnString = JSONParser.toJson(product2);

				response = Response.ok(returnString).build();
			}

		} catch (Exception e) {

			Product beanForMessage = new Product();
			beanForMessage.setMessage(AppConfig.PROPERTIES.getProperty(e
					.getMessage()));
			String returnString = JSONParser.toJson(beanForMessage);
			if (e.getMessage().contains("DAO")) {
				response = Response.status(Status.SERVICE_UNAVAILABLE)
						.entity(returnString).build();
			} else {
				response = Response.status(Status.BAD_REQUEST)
						.entity(returnString).build();

			}
		}

		return response;
	}

	// update the details of a product
	@PUT
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public Response updateProductDetails(String dataRecieved) throws Exception {
		Response response = null;

		Product product = JSONParser.fromJson(dataRecieved, Product.class);
		try {

			ProductService productService = Factory.createProductService();
			productService.updateProductDetails(product);
			String message = AppConfig.PROPERTIES
					.getProperty("ProductAPI.SUCCESSFUL_UPDATE");

			Product beanForMessage = new Product();
			beanForMessage.setMessage(message);
			String returnString = JSONParser.toJson(beanForMessage);
			response = Response.status(Status.OK).entity(returnString).build();

		} catch (Exception e) {

			Product beanForMessage = new Product();
			beanForMessage.setMessage(AppConfig.PROPERTIES.getProperty(e
					.getMessage()));
			String returnString = JSONParser.toJson(beanForMessage);
			if (e.getMessage().contains("DAO")) {
				response = Response.status(Status.SERVICE_UNAVAILABLE)
						.entity(returnString).build();
			} else {
				response = Response.status(Status.BAD_REQUEST)
						.entity(returnString).build();

			}
		}

		return response;
	}

	// get product details by category
	@GET
	@Path("productByCategory/{category}")
	@Produces(MediaType.APPLICATION_JSON)
	public Response getProductDetailsByCategory(
			@PathParam("category") String category) throws Exception {
		Response response = null;

		try {
			ProductService productService = Factory.createProductService();
			List<Product> productList = productService
					.getProductByCategory(category);

			String returnString = JSONParser.toJson(productList);

			response = Response.ok(returnString).build();
		} catch (Exception e) {

			Product beanForMessage = new Product();
			beanForMessage.setMessage(AppConfig.PROPERTIES.getProperty(e
					.getMessage()));
			String returnString = JSONParser.toJson(beanForMessage);
			if (e.getMessage().contains("DAO")) {
				response = Response.status(Status.SERVICE_UNAVAILABLE)
						.entity(returnString).build();
			} else {
				response = Response.status(Status.BAD_REQUEST)
						.entity(returnString).build();

			}
		}

		return response;
	}

}
