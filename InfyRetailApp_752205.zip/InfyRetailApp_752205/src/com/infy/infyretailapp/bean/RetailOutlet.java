package com.infy.infyretailapp.bean;

import java.util.List;

public class RetailOutlet {

	private Integer retailOutletId;
	private String retailOutletName;
	private String city;
	private List<Offers> offers;

	public Integer getRetailOutletId() {
		return retailOutletId;
	}

	public void setRetailOutletId(Integer retailOutletId) {
		this.retailOutletId = retailOutletId;
	}

	public String getRetailOutletName() {
		return retailOutletName;
	}

	public void setRetailOutletName(String retailOutletName) {
		this.retailOutletName = retailOutletName;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public List<Offers> getOffers() {
		return offers;
	}

	public void setOffers(List<Offers> offers) {
		this.offers = offers;
	}

}
