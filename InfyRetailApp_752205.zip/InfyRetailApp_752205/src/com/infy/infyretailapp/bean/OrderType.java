package com.infy.infyretailapp.bean;

public enum OrderType {
	CUSTOMER, SUPPLIER
}
