package com.infy.infyretailapp.bean;

public enum UserType {
	GOLD, SILVER, PLATINUM
}
