package com.infy.infyretailapp.dao;

import java.util.List;

import com.infy.infyretailapp.bean.Feedback;
import com.infy.infyretailapp.bean.User;

public interface UserDAO
{
	
	public Integer submitFeedback(Feedback feedback) throws Exception;
	public String addUser(User user) throws Exception;
	public User findUser(String userId) throws Exception;
	public List<User> getAllUsers(String userRole) throws Exception;
	
	public void updateUser(User user) throws Exception;
	public void changePassword(String userId, String oldPassword, String newPassword) throws Exception;
	public void deactivateUser(String userId) throws Exception;
	
	public void updateUserDetails(User user) throws Exception;
	public List<User> getOnlyUsers() throws Exception;
	public List<Feedback> getAllFeedback() throws Exception;
}
