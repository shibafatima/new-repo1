package com.infy.infyretailapp.dao;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;

import com.infy.infyretailapp.bean.User;
import com.infy.infyretailapp.entity.UserEntity;
import com.infy.infyretailapp.resources.HibernateUtility;

public class LoginDAOImpl implements LoginDAO {

	@Override
	@SuppressWarnings("unchecked")
	public List<User> getUserDetails(String userName, String password)
			throws Exception {
		List<User> listOfUsers = new ArrayList<User>();
		User user = new User();
		SessionFactory sessionFactory = HibernateUtility.createSessionFactory();
		Session session = null;
		try {
			session = sessionFactory.openSession();
			// find operation works on the primary key s
			Query query = session
					.createQuery("select u from UserEntity u where u.userName=?");
			query.setParameter(0, userName);

			List<UserEntity> userEntityList = query.list();

			for (UserEntity userEntity : userEntityList) {
				// Creating the UserTO object
				user = new User();

				// Setting values to userTO object from userEntity object
				user.setDateOfBirth(userEntity.getDateOfBirth());
				user.setUserName(userEntity.getUserName());
				user.setEmail(userEntity.getEmail());
				user.setGender(userEntity.getGender().toString());
				user.setPassword(userEntity.getPassword());
				user.setUserId(userEntity.getUserId());
				user.setUserRole(userEntity.getUserRole().toString());
				listOfUsers.add(user);
			}
		} catch (Exception exception) {
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw new Exception("DAO.TECHNICAL_ERROR");
		} finally {
			if (session != null) {
				session.close();
			}
		}
		return listOfUsers;
	}

}
