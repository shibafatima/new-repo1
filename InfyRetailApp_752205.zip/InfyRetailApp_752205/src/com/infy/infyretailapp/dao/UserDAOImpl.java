package com.infy.infyretailapp.dao;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;

import com.infy.infyretailapp.bean.Address;
import com.infy.infyretailapp.bean.Feedback;
import com.infy.infyretailapp.bean.User;
import com.infy.infyretailapp.entity.AddressEntity;
import com.infy.infyretailapp.entity.FeedbackEntity;
import com.infy.infyretailapp.entity.UserEntity;
import com.infy.infyretailapp.resources.HibernateUtility;

/**
 * DAO class to perform database operations
 * 
 * @author ETA
 */

public class UserDAOImpl implements UserDAO {
	
	
	/**
	 * Submits the feedback written by the user for a product
	 * @param feedback
	 * 
	 * @return feedbackId
	 */
	@Override
	public Integer submitFeedback(Feedback feedback) throws Exception {
		// TODO Auto-generated method stub
		Session session = null;
		FeedbackEntity entity = new FeedbackEntity();
		try
		{
			SessionFactory sessionFactory = HibernateUtility.createSessionFactory();
			session = sessionFactory.openSession();
			session.beginTransaction();
			
			entity.setUserId(feedback.getUserId());
			entity.setRating(feedback.getRating());
			entity.setDescription(feedback.getDescription());
			entity.setFeedbackDate(feedback.getFeedbackDate());
			entity.setProductId(feedback.getProductId());
			session.persist(entity);
			session.getTransaction().commit();
			
		}
		catch (Exception exception) {
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw new Exception("DAO.TECHNICAL_ERROR");
		} finally {
			if (session != null && session.isOpen()) {
				session.close();
			}
		}
		return entity.getFeedbackId();
	}
	
	/**
	 * Adds user to the database
	 * 
	 * @param user
	 *            , the user to be added
	 * @return The user ID of the newly added user
	 */
	@Override
	public String addUser(User user) throws Exception {
		SessionFactory sessionFactory = HibernateUtility.createSessionFactory();
		Session session = null;
		UserEntity entity = new UserEntity();
		AddressEntity addressEntity = new AddressEntity();

		try {

			session = sessionFactory.openSession();
			session.beginTransaction();
			addressEntity.setCity(user.getAddress().getCity());
			addressEntity.setDoorNo(user.getAddress().getDoorNumber());
			addressEntity.setStreet(user.getAddress().getStreet());
			addressEntity.setState(user.getAddress().getState());
			addressEntity.setPin(user.getAddress().getPinCode());
			session.save(addressEntity);

			entity.setUserId(user.getUserId());
			entity.setUserName(user.getUserName());
			entity.setUserRole(user.getUserRole().getUserRoleValue());
			entity.setPassword(user.getPassword());
			entity.setEmail(user.getEmail());
			entity.setMobileNumber(user.getMobileNumber());
			entity.setDateOfBirth(user.getDateOfBirth());
			entity.setAddress(addressEntity);
			entity.setGender(user.getGender().getGenderValue());
			entity.setUserType(user.getUserType().toString());
			entity.setUserStatus(user.getUserStatus());

			session.persist(entity);
			session.getTransaction().commit();
		} catch (Exception exception) {
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw new Exception("DAO.TECHNICAL_ERROR");
		} finally {
			if (session.isOpen() || session != null) {
				session.close();
			}
		}
		return user.getUserId();
	}

	// added by FA3
	public void updateUserDetails(User user) throws Exception {

		SessionFactory sessionFactory = HibernateUtility.createSessionFactory();
		Session session = null;

		try {

			session = sessionFactory.openSession();
			UserEntity entity = (UserEntity) session.get(UserEntity.class,
					user.getUserId());
			session.getTransaction().begin();

			entity.setEmail(user.getEmail());
			entity.setMobileNumber(user.getMobileNumber());
			session.getTransaction().commit();

		} catch (Exception exception) {
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw new Exception("DAO.TECHNICAL_ERROR");
		} finally {
			if (session.isOpen() || session != null) {
				session.close();
			}

		}

	}

	/**
	 * To get a user's details
	 * 
	 * @param userId
	 * @return The user details of the specified user
	 */
	@Override
	public User findUser(String userId) throws Exception {

		SessionFactory sessionFactory = HibernateUtility.createSessionFactory();
		Session session = null;
		User user = null;
		Address address = null;

		try {

			session = sessionFactory.openSession();
			UserEntity entity = (UserEntity) session.get(UserEntity.class,
					userId);

			if (entity != null) {
				user = new User();
				user.setUserId(userId);
				user.setUserName(entity.getUserName());
				user.setEmail(entity.getEmail());
				user.setMobileNumber(entity.getMobileNumber());
				user.setDateOfBirth(entity.getDateOfBirth());
				user.setGender(entity.getGender().toString());
				if (entity.getUserRole() == 'C') {
					user.setUserType(entity.getUserType());
				}
				user.setUserRole(entity.getUserRole().toString());
				address = new Address(entity.getAddress().getDoorNo(), entity
						.getAddress().getStreet(), entity.getAddress()
						.getCity(), entity.getAddress().getState(), entity
						.getAddress().getPin());
				user.setAddress(address);

			}

		} catch (Exception exception) {
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw new Exception("DAO.TECHNICAL_ERROR");
		} finally {
			if (session.isOpen() || session != null) {
				session.close();
			}
		}
		return user;
	}

	// added by FA#
	@SuppressWarnings("unchecked")
	public List<User> getOnlyUsers() throws Exception {
		SessionFactory sessionFactory = HibernateUtility.createSessionFactory();
		Session session = null;
		List<User> users = new ArrayList<User>();

		try {

			session = sessionFactory.openSession();
			Query query = session
					.createQuery("select user.userId,user.userName,user.mobileNumber,user.userRole,user.userType,user.userStatus from UserEntity user where userRole=?");
			char cha = 'C';
			query.setParameter(0, cha);

			List<Object[]> obj = query.list();

			for (Object[] objects : obj) {
				User user = new User();
				user.setUserId((String) objects[0]);
				user.setUserName((String) objects[1]);
				user.setMobileNumber((String) objects[2]);
				user.setUserRole((String.valueOf(objects[3])));
				user.setUserType((String) objects[4]);
				user.setUserStatus((Character) objects[5]);
				users.add(user);
			}

		} catch (Exception exception) {
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw new Exception("DAO.TECHNICAL_ERROR");
		} finally {
			if (session.isOpen() || session != null) {
				session.close();
			}
		}
		return users;
	}
	 
	@Override
	@SuppressWarnings("unchecked")
	public List<Feedback> getAllFeedback() throws Exception {
		SessionFactory sessionFactory = HibernateUtility.createSessionFactory();
		Session session = null;
		List<Feedback> feeds = new ArrayList<Feedback>();
		try{
			session = sessionFactory.openSession();
			Query query = session.createQuery("from FeedbackEntity");
			List<FeedbackEntity> entities = query.list();
			for(FeedbackEntity fe:entities) {
				UserEntity ue = (UserEntity)session.get(UserEntity.class,fe.getUserId());
				Feedback feedback = new Feedback();
				feedback.setUserName(ue.getUserName());
				feedback.setFeedbackId(fe.getFeedbackId());
				feedback.setProductId(fe.getProductId());
				feedback.setFeedbackDate(fe.getFeedbackDate());
				feedback.setRating(fe.getRating());
				feedback.setDescription(fe.getDescription());
				feeds.add(feedback);
			}
			session.getTransaction().commit();
		}
		catch(Exception exception) {
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw new Exception("DAO.TECHNICAL_ERROR");
		} 
		finally {
			if (session.isOpen() || session != null) {
				session.close();
			}
		}
		return feeds;
	}
	
	
	
	@Override
	@SuppressWarnings("unchecked")
	public List<User> getAllUsers(String userRole) throws Exception {
		SessionFactory sessionFactory = HibernateUtility.createSessionFactory();
		Session session = null;
		List<User> users = new ArrayList<User>();

		try {

			session = sessionFactory.openSession();

			Criteria criteria = session.createCriteria(UserEntity.class);
			criteria.add(Restrictions.like("userRole", userRole.charAt(0)));
			List<UserEntity> obj = criteria.list();
			for (UserEntity userEntity : obj) {
				User user = new User();
				user.setUserId(userEntity.getUserId());
				user.setUserName(userEntity.getUserName());
				user.setMobileNumber(userEntity.getMobileNumber());
				user.setUserRole(userEntity.getUserRole().toString());
				user.setUserType(userEntity.getUserType());
				users.add(user);

			}

		} catch (Exception exception) {
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw new Exception("DAO.TECHNICAL_ERROR");
		} finally {
			if (session.isOpen() || session != null) {
				session.close();
			}
		}
		return users;
	}

	/**
	 * Updates existing user in the database
	 * 
	 * @param user
	 *            , the user to be updated
	 */
	@Override
	public void updateUser(User user) throws Exception {
		// Update user in the database

		SessionFactory sessionFactory = HibernateUtility.createSessionFactory();
		Session session = null;

		try {

			session = sessionFactory.openSession();
			UserEntity entity = (UserEntity) session.get(UserEntity.class,
					user.getUserId());
			session.getTransaction().begin();
			entity.setUserId(user.getUserId());
			entity.setUserName(user.getUserName());
			entity.setEmail(user.getEmail());
			entity.setMobileNumber(user.getMobileNumber());
			entity.setDateOfBirth(user.getDateOfBirth());
			AddressEntity addressEntity = new AddressEntity();

			addressEntity.setCity(user.getAddress().getCity());
			addressEntity.setDoorNo(user.getAddress().getDoorNumber());
			addressEntity.setStreet(user.getAddress().getStreet());
			addressEntity.setState(user.getAddress().getState());
			addressEntity.setPin(user.getAddress().getPinCode());
			entity.setAddress(addressEntity);
			entity.setGender(user.getGender().getGenderValue());
			entity.setUserType(user.getUserType().toString());
			session.getTransaction().commit();

		} catch (Exception exception) {
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw new Exception("DAO.TECHNICAL_ERROR");
		} finally {
			if (session.isOpen() || session != null) {
				session.close();
			}
		}
	}

	/**
	 * Changes existing user's password in the database
	 * 
	 * @param userId
	 *            , oldPassword, newPassword
	 */
	@Override
	public void changePassword(String userId, String oldPassword,
			String newPassword) throws Exception {
		// Check oldPassword
		// Update to newPassword
		SessionFactory sessionFactory = HibernateUtility.createSessionFactory();
		Session session = null;

		try {

			session = sessionFactory.openSession();
			UserEntity entity = (UserEntity) session.get(UserEntity.class,
					userId);
			if (entity.getPassword().equals(oldPassword)) {
				session.getTransaction().begin();
				entity.setPassword(newPassword);
				session.getTransaction().commit();
			}

		} catch (Exception exception) {
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw new Exception("DAO.TECHNICAL_ERROR");
		} finally {
			if (session.isOpen() || session != null) {
				session.close();
			}
		}

	}

	/**
	 * Removes the user from the database
	 * 
	 * @param userId
	 *            , user ID of the user to be removed
	 */
	@Override
	public void deactivateUser(String userId) throws Exception {
		// Delete the user from the database
		// Delete the user from the database
		SessionFactory sessionFactory = HibernateUtility.createSessionFactory();
		Session session = null;

		try {

			session = sessionFactory.openSession();

			UserEntity entity = (UserEntity) session.get(UserEntity.class,
					userId);
			if (entity != null) {
				session.getTransaction().begin();
				entity.setUserStatus('D');
				session.getTransaction().commit();

			}

		} catch (Exception exception) {
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw new Exception("DAO.TECHNICAL_ERROR");
		} finally {
			if (session.isOpen() || session != null) {
				session.close();
			}
		}

	}

}

///////@Override
	@SuppressWarnings("unchecked")
	public List<Feedback> getAllFeedback() throws Exception {
		SessionFactory sessionFactory = HibernateUtility.createSessionFactory();
		Session session = null;
		List<Feedback> feeds = new ArrayList<Feedback>();
		try{
			session = sessionFactory.openSession();
			Query query = session.createQuery("from FeedbackEntity");
			List<FeedbackEntity> entities = query.list();
			for(FeedbackEntity fe:entities) {
				UserEntity ue = (UserEntity)session.get(UserEntity.class,fe.getUserId());
				Feedback feedback = new Feedback();
				feedback.setUserName(ue.getUserName());
				feedback.setFeedbackId(fe.getFeedbackId());
				feedback.setProductId(fe.getProductId());
				feedback.setFeedbackDate(fe.getFeedbackDate());
				feedback.setRating(fe.getRating());
				feedback.setDescription(fe.getDescription());
				feeds.add(feedback);
			}
			session.getTransaction().commit();
		}
		catch(Exception exception) {
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw new Exception("DAO.TECHNICAL_ERROR");
		} 
		finally {
			if (session.isOpen() || session != null) {
				session.close();
			}
		}
		return feeds;
	}

}///////////

