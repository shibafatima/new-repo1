package com.infy.infyretailapp.dao;

import java.util.List;

import com.infy.infyretailapp.bean.User;

public interface LoginDAO {

	public List<User> getUserDetails(String userName, String password) throws Exception;


}
