package com.infy.infyretailapp.dao;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;

import com.infy.infyretailapp.bean.Product;
import com.infy.infyretailapp.bean.User;
import com.infy.infyretailapp.entity.OrderProductEntity;
import com.infy.infyretailapp.entity.ProductEntity;
import com.infy.infyretailapp.entity.UserEntity;
import com.infy.infyretailapp.resources.HibernateUtility;

public class ProductDAOImpl implements ProductDAO {
	@Override
	public Product findProduct(Integer productId) throws Exception {
		SessionFactory sessionFactory = null;
		Session session = null;
		try

		{
			sessionFactory = HibernateUtility.createSessionFactory();
			session = sessionFactory.openSession();
			ProductEntity productEntity = (ProductEntity) session.get(
					ProductEntity.class, productId);
			Product product = new Product();
			if (productEntity != null) {
				product.setProductId(productEntity.getProductId());
				product.setName(productEntity.getName());
				product.setBrand(productEntity.getBrand());
				product.setCategory(productEntity.getCategory());
				product.setCost(productEntity.getCost());
				product.setDiscount(productEntity.getDiscount());
				product.setQuantity(productEntity.getQuantity());
				product.setSellingPrice(productEntity.getSellingPrice());
				product.setSpecification(productEntity.getSpecification());

				User user = new User();
				user.setUserId(productEntity.getSupplier().getUserId());
				product.setSupplier(user);
				return product;
			}
			return null;
		} catch (Exception e) {
			Logger logger = Logger.getLogger(this.getClass());
			logger.debug(e.getMessage(), e);
			throw new Exception("DAO.TECHINAL_ERROR");
		} finally {
			if (session.isOpen() || session != null) {
				session.close();
			}
		}
	}

	/**
	 * Adds product to the database
	 * 
	 * @param product
	 *            , the product to be added
	 * @return The product ID of the newly added product
	 */

	@Override
	@SuppressWarnings("unchecked")
	public List<Product> getProductByCategory(String category) throws Exception {
		SessionFactory sessionFactory = null;
		Session session = null;
		List<Product> productList = new ArrayList<Product>();
		try

		{
			sessionFactory = HibernateUtility.createSessionFactory();
			session = sessionFactory.openSession();

			Query query = session
					.createQuery("select product from ProductEntity product where product.category=?");
			query.setParameter(0, category);
			List<ProductEntity> list = query.list();

			if (!list.isEmpty()) {
				for (ProductEntity productEntity : list) {
					Product product = new Product();
					product.setProductId(productEntity.getProductId());
					product.setName(productEntity.getName());
					product.setBrand(productEntity.getBrand());
					product.setCategory(productEntity.getCategory());
					product.setCost(productEntity.getCost());
					product.setDiscount(productEntity.getDiscount());
					product.setQuantity(productEntity.getQuantity());
					product.setSellingPrice(productEntity.getSellingPrice());
					product.setSpecification(productEntity.getSpecification());

					User user = new User();
					user.setUserId(productEntity.getSupplier().getUserId());
					product.setSupplier(user);

					productList.add(product);

				}
				return productList;
			}

			return null;
		} catch (Exception e) {
			Logger logger = Logger.getLogger(this.getClass());
			logger.debug(e.getMessage(), e);
			throw new Exception("DAO.TECHINAL_ERROR");
		} finally {
			if (session.isOpen() || session != null) {
				session.close();
			}
		}
	}

	@Override
	public Integer addProduct(Product product) throws Exception {

		SessionFactory sessionFactory = null;
		Session session = null;

		try {
			sessionFactory = HibernateUtility.createSessionFactory();
			session = sessionFactory.openSession();
			UserEntity userEntity = (UserEntity) session.get(UserEntity.class,
					product.getSupplier().getUserId());
			ProductEntity productEntity = new ProductEntity();
			productEntity.setProductId(product.getProductId());
			productEntity.setName(product.getName());
			productEntity.setBrand(product.getBrand());
			productEntity.setCategory(product.getCategory());
			productEntity.setCost(product.getCost());
			productEntity.setDiscount(product.getDiscount());
			productEntity.setQuantity(product.getQuantity());
			productEntity.setSellingPrice(product.getSellingPrice());
			productEntity.setSpecification(product.getSpecification());

			userEntity.setUserId(product.getSupplier().getUserId());
			productEntity.setSupplier(userEntity);

			session.beginTransaction();
			Integer productId = (Integer) session.save(productEntity);
			session.getTransaction().commit();
			return productId;

		} catch (Exception e) {
			e.printStackTrace();
			Logger logger = Logger.getLogger(this.getClass());
			logger.debug(e.getMessage(), e);
			throw new Exception("DAO.TECHINAL_ERROR");
		} finally {
			if (session.isOpen() || session != null) {
				session.close();
			}
		}
	}

	// added by FA3
	public void updateProductDetails(Product product) throws Exception {
		SessionFactory sessionFactory = null;
		Session session = null;

		try {
			sessionFactory = HibernateUtility.createSessionFactory();
			session = sessionFactory.openSession();

			ProductEntity productEntity = (ProductEntity) session.get(
					ProductEntity.class, product.getProductId());

			session.beginTransaction();
			productEntity.setSellingPrice(product.getSellingPrice());
			productEntity.setQuantity(product.getQuantity());
			session.getTransaction().commit();

		} catch (Exception e) {
			Logger logger = Logger.getLogger(this.getClass());
			logger.debug(e.getMessage(), e);
			throw new Exception("DAO.TECHINAL_ERROR");
		} finally {
			if (session.isOpen() || session != null) {
				session.close();
			}

		}
	}

	@Override
	public void updateProduct(Product product) throws Exception {
		SessionFactory sessionFactory = null;
		Session session = null;

		try {
			sessionFactory = HibernateUtility.createSessionFactory();
			session = sessionFactory.openSession();

			UserEntity userEntity = (UserEntity) session.get(UserEntity.class,
					product.getSupplier().getUserId());

			ProductEntity productEntity = (ProductEntity) session.get(
					ProductEntity.class, product.getProductId());

			productEntity.setSupplier(userEntity);

			session.beginTransaction();

			session.getTransaction().commit();

		} catch (Exception e) {
			Logger logger = Logger.getLogger(this.getClass());
			logger.debug(e.getMessage(), e);
			throw new Exception("DAO.TECHINAL_ERROR");
		} finally {
			if (session.isOpen() || session != null) {
				session.close();
			}
		}
	}

	/**
	 * Removes the product from the database
	 * 
	 * @param productId
	 *            , product ID of the product to be removed
	 */
	@Override
	@SuppressWarnings("unchecked")
	public Integer deleteProduct(Integer productId) throws Exception {
		SessionFactory sessionFactory = null;
		Session session = null;

		try {
			sessionFactory = HibernateUtility.createSessionFactory();
			session = sessionFactory.openSession();

			Query query = session
					.createQuery("select ope from OrderProductEntity ope where ope.primaryKey.productId=?");
			query.setParameter(0, productId);
			List<OrderProductEntity> list = new ArrayList<OrderProductEntity>();
			list = query.list();
			if (list.isEmpty()) {
				ProductEntity productEntity = (ProductEntity) session.get(
						ProductEntity.class, productId);
				if (productEntity != null) {
					productEntity.setSupplier(null);
					session.beginTransaction();
					session.delete(productEntity);
					session.getTransaction().commit();
				}
				return productId;

			}
			return null;
		}

		catch (Exception e) {
			Logger logger = Logger.getLogger(this.getClass());
			logger.debug(e.getMessage(), e);
			throw new Exception("DAO.TECHINAL_ERROR");
		} finally {
			if (session.isOpen() || session != null) {
				session.close();
			}
		}
	}

	/**
	 * To get a product's details
	 * 
	 * @param productId
	 * @return The product details of the specified product
	 */
	@Override
	public Product getProductDetails(Integer productId) throws Exception {

		SessionFactory sessionFactory = null;
		Session session = null;
		Product product = null;
		try {
			sessionFactory = HibernateUtility.createSessionFactory();
			session = sessionFactory.openSession();

			ProductEntity productEntity = (ProductEntity) session.get(
					ProductEntity.class, productId);
			if (productEntity != null) {
				product = new Product();
				product.setProductId(productEntity.getProductId());
				product.setName(productEntity.getName());
				product.setCost(productEntity.getCost());
				product.setSellingPrice(productEntity.getSellingPrice());
				product.setQuantity(productEntity.getQuantity());
				product.setSpecification(productEntity.getSpecification());
			}

		} catch (Exception e) {
			Logger logger = Logger.getLogger(this.getClass());
			logger.debug(e.getMessage(), e);
			throw new Exception("DAO.TECHINAL_ERROR");
		} finally {
			if (session.isOpen() || session != null) {
				session.close();
			}
		}
		return product;
	}

	// added by FA3
	@SuppressWarnings("unchecked")
	public List<Product> getAllProducts() throws Exception {

		SessionFactory sessionFactory = HibernateUtility.createSessionFactory();
		Session session = null;
		List<Product> products = new ArrayList<Product>();

		try {

			session = sessionFactory.openSession();
			Query query = session
					.createQuery("select product from ProductEntity product");

			List<ProductEntity> entity = query.list();

			for (ProductEntity productEntity : entity) {
				Product product = new Product();
				product.setProductId(productEntity.getProductId());
				product.setName(productEntity.getName());
				product.setBrand(productEntity.getBrand());
				product.setCategory(productEntity.getCategory());
				product.setQuantity(productEntity.getQuantity());
				product.setCost(productEntity.getCost());
				product.setSellingPrice(productEntity.getSellingPrice());
				product.setSpecification(productEntity.getSpecification());
				product.setDiscount(productEntity.getDiscount());
				User user = new User();
				user.setUserId(productEntity.getSupplier().getUserId());
				product.setSupplier(user);
				products.add(product);
			}

			return products;
		}

		catch (Exception e) {
			Logger logger = Logger.getLogger(this.getClass());
			logger.debug(e.getMessage(), e);
			throw new Exception("DAO.TECHINAL_ERROR");
		} finally {
			if (session.isOpen() || session != null) {
				session.close();
			}
		}

	}

	@Override
	@SuppressWarnings("unchecked")
	public List<Product> getProductsInPriceRange(Double min, Double max)
			throws Exception {

		SessionFactory sessionFactory = HibernateUtility.createSessionFactory();
		Session session = null;
		List<Product> products = new ArrayList<Product>();

		try {

			session = sessionFactory.openSession();
			/*
			 * Query query = session .createQuery(
			 * "select product from ProductEntity product where cost>? and cost<?"
			 * ); query.setParameter(0,min); query.setParameter(1,max);
			 */

			Criteria criteria = session.createCriteria(ProductEntity.class);
			criteria.add(Restrictions.gt("cost", min));
			criteria.add(Restrictions.lt("cost", max));

			List<ProductEntity> entity = criteria.list();

			for (ProductEntity productEntity : entity) {
				Product product = new Product();
				product.setProductId(productEntity.getProductId());
				product.setName(productEntity.getName());
				product.setBrand(productEntity.getBrand());
				product.setCategory(productEntity.getCategory());
				product.setQuantity(productEntity.getQuantity());
				product.setCost(productEntity.getCost());
				product.setSellingPrice(productEntity.getSellingPrice());
				product.setSpecification(productEntity.getSpecification());
				product.setDiscount(productEntity.getDiscount());
				User user = new User();
				user.setUserId(productEntity.getSupplier().getUserId());
				product.setSupplier(user);
				products.add(product);
			}

			return products;
		}

		catch (Exception e) {
			Logger logger = Logger.getLogger(this.getClass());
			logger.debug(e.getMessage(), e);
			throw new Exception("DAO.TECHINAL_ERROR");
		} finally {
			if (session.isOpen() || session != null) {
				session.close();
			}
		}

	}

	@SuppressWarnings("rawtypes")
	@Override
	public Long getCountOfProducts(String supplierId) throws Exception {

		SessionFactory sessionFactory = HibernateUtility.createSessionFactory();
		Session session = null;

		try {

			session = sessionFactory.openSession();

			Criteria criteria = session.createCriteria(ProductEntity.class);
			criteria.add(Restrictions.like("supplier.userId", supplierId));
			criteria.setProjection(Projections.rowCount());
			List rowCount = criteria.list();
			Long count = (Long) rowCount.get(0);
			return count;

		} catch (Exception exception) {
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw new Exception("DAO.TECHNICAL_ERROR");
		} finally {
			if (session.isOpen() || session != null) {
				session.close();
			}
		}

	}

	// added by FA3
	@SuppressWarnings("unchecked")
	public List<String> getCategoryDetails() throws Exception {
		SessionFactory sessionFactory = HibernateUtility.createSessionFactory();
		Session session = null;

		try {

			session = sessionFactory.openSession();
			Query query = session
					.createQuery("select DISTINCT product.category from ProductEntity product");

			List<String> supplier = query.list();
			return supplier;

		} catch (Exception exception) {
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw new Exception("DAO.TECHNICAL_ERROR");
		} finally {
			if (session.isOpen() || session != null) {
				session.close();
			}
		}
	}

	// added by FA3
	@SuppressWarnings("unchecked")
	public List<String> getSupplierIdList() throws Exception {

		SessionFactory sessionFactory = HibernateUtility.createSessionFactory();
		Session session = null;

		try {

			session = sessionFactory.openSession();
			Query query = session
					.createQuery("select DISTINCT product.supplier.userId from ProductEntity product where product.supplier.userId LIKE 'S%'");

			List<String> supplier = query.list();
			return supplier;

		} catch (Exception exception) {
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw new Exception("DAO.TECHNICAL_ERROR");
		} finally {
			if (session.isOpen() || session != null) {
				session.close();
			}
		}
	}
}
