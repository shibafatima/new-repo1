package com.infy.infyretailapp.dao;

import java.util.Calendar;
import java.util.List;

import com.infy.infyretailapp.bean.Order;
import com.infy.infyretailapp.bean.Product;

public interface OrderDAO
{
	public Order viewOrder(Integer orderId) throws Exception;
	public Integer placeOrder(Order order) throws Exception;
	public Integer getOrderProductDetails(Integer orderId,Integer productId) throws Exception;
	public List<Order> showOrdersByUser(String userId) throws Exception;
	public List<Order> showOrdersByDate(Calendar date) throws Exception;
	
	public List<Order> showAllOrders() throws Exception;
	public List<Product> getProductNamesOrderedByUserId(String userId) throws Exception;
}
