package com.infy.infyretailapp.dao;

import java.util.List;

import com.infy.infyretailapp.bean.Product;

public interface ProductDAO
{
	public Product findProduct(Integer productId) throws Exception;
	public Integer addProduct(Product product) throws Exception;
	public void updateProduct(Product product) throws Exception; 
	public Integer deleteProduct(Integer productId) throws Exception;
	public Product getProductDetails(Integer productId) throws Exception;
	public List<Product> getProductsInPriceRange(Double min, Double max) throws Exception;
	public Long getCountOfProducts(String supplierId) throws Exception;
	
	public void updateProductDetails(Product product) throws Exception;
	public List<Product> getAllProducts() throws Exception;
	public List<String> getCategoryDetails() throws Exception;
	public List<String> getSupplierIdList() throws Exception;
	public List<Product> getProductByCategory(String category) throws Exception;
}
