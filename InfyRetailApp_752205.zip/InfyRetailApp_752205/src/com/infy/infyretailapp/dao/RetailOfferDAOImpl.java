package com.infy.infyretailapp.dao;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.SessionFactory;

import com.infy.infyretailapp.bean.Offers;
import com.infy.infyretailapp.bean.RetailOutlet;
import com.infy.infyretailapp.entity.OfferEntity;
import com.infy.infyretailapp.entity.RetailOutletEntity;
import com.infy.infyretailapp.resources.HibernateUtility;

public class RetailOfferDAOImpl implements RetailOfferDAO {

	public RetailOutlet addRetailOutletAndExistingOffer(
			RetailOutlet retailOutlet) throws Exception {
		SessionFactory sessionFactory = HibernateUtility.createSessionFactory();
		Session session = null;
		List<OfferEntity> offersList = new ArrayList<OfferEntity>();
		List<Offers> offersListBean = new ArrayList<Offers>();

		try {

			session = sessionFactory.openSession();
			session.beginTransaction();
			RetailOutletEntity retailOutletEntity = new RetailOutletEntity();
			retailOutletEntity.setRetailOutletId(retailOutlet
					.getRetailOutletId());
			retailOutletEntity.setRetailOutletName(retailOutlet
					.getRetailOutletName());
			retailOutletEntity.setCity(retailOutlet.getCity());

			for (Offers offers : retailOutlet.getOffers()) {

				OfferEntity offerEntity = new OfferEntity();
				offerEntity = (OfferEntity) session.get(OfferEntity.class,
						offers.getOfferId());
				if (offerEntity != null) {
					offersList.add(offerEntity);
					offersListBean.add(offers);
				}

			}

			retailOutletEntity.setOffers(offersList);
			session.save(retailOutletEntity);
			session.getTransaction().commit();
			retailOutlet.setOffers(offersListBean);
		} catch (Exception exception) {
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw new Exception("DAO.TECHNICAL_ERROR");
		} finally {
			if (session.isOpen() || session != null) {
				session.close();
			}
		}

		return retailOutlet;
	}

	@Override
	public Integer deleteOffersForRetailOutlet(Integer retailOutletId,
			List<Offers> offers) throws Exception {
		// TODO Auto-generated method stub

		SessionFactory sessionFactory = HibernateUtility.createSessionFactory();
		Session session = null;

		try {

			session = sessionFactory.openSession();

			RetailOutletEntity retailOutletEntity = (RetailOutletEntity) session
					.get(RetailOutletEntity.class, retailOutletId);
			List<OfferEntity> offerEntities1 = retailOutletEntity.getOffers();
			List<OfferEntity> offerEntities2 = new ArrayList<OfferEntity>();

			for (OfferEntity offerEntity : offerEntities1) {
				offerEntities2.add(offerEntity);
			}

			for (OfferEntity offerEntity : offerEntities1) {

				for (Offers offerId : offers) {

					if (offerEntity.getOfferId().equals(offerId.getOfferId())) {
						offerEntities2.remove(offerEntity);

					}

				}

			}

			session.beginTransaction();
			retailOutletEntity.setOffers(offerEntities2);
			session.getTransaction().commit();

		} catch (Exception exception) {
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(exception.getMessage(), exception);
			throw new Exception("DAO.TECHNICAL_ERROR");
		} finally {
			if (session.isOpen() || session != null) {
				session.close();
			}
		}

		return retailOutletId;

	}

	public void addNewOffersToExistingRetail(RetailOutlet retailOutlet)
			throws Exception {
		SessionFactory sessionFactory = null;
		Session session = null;
		try {
			sessionFactory = HibernateUtility.createSessionFactory();
			session = sessionFactory.openSession();
			RetailOutletEntity re = (RetailOutletEntity) session.get(
					RetailOutletEntity.class, retailOutlet.getRetailOutletId());

			List<OfferEntity> oeList = re.getOffers();
			for (Offers offer : retailOutlet.getOffers()) {
				OfferEntity oe = new OfferEntity();
				oe.setOfferId(offer.getOfferId());
				oe.setOfferMonth(offer.getMonth());
				oe.setOfferName(offer.getOfferName());

				session.persist(oe);

				oeList.add(oe);

			}

			re.setOffers(oeList);
			session.beginTransaction();
			session.getTransaction().commit();

		} catch (Exception e) {
			Logger logger = Logger.getLogger(this.getClass());
			logger.debug(e.getMessage(), e);
			throw new Exception("DAO.TECHINAL_ERROR");
		} finally {
			if (session.isOpen() || session != null) {
				session.close();
			}
		}
	}

	public List<Offers> getAllOfferForRetail(Integer retailOutletId)
			throws Exception {
		SessionFactory sessionFactory = null;
		Session session = null;
		List<Offers> offerList = new ArrayList<Offers>();
		try {
			sessionFactory = HibernateUtility.createSessionFactory();
			session = sessionFactory.openSession();

			RetailOutletEntity re = (RetailOutletEntity) session.get(
					RetailOutletEntity.class, retailOutletId);
			if (re != null) {
				List<OfferEntity> offerEntityList = re.getOffers();
				for (OfferEntity oe : offerEntityList) {
					Offers offers = new Offers();
					offers.setOfferId(oe.getOfferId());
					offers.setOfferName(oe.getOfferName());
					offers.setMonth(oe.getOfferMonth());
					offerList.add(offers);
				}
			}
			return offerList;

		} catch (Exception e) {
			Logger logger = Logger.getLogger(this.getClass());
			logger.debug(e.getMessage(), e);
			throw new Exception("DAO.TECHINAL_ERROR");
		} finally {
			if (session.isOpen() || session != null) {
				session.close();
			}
		}
	}

}
