package com.infy.infyretailapp.dao;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;

import com.infy.infyretailapp.bean.Order;
import com.infy.infyretailapp.bean.OrderProduct;
import com.infy.infyretailapp.bean.Product;
import com.infy.infyretailapp.bean.User;
import com.infy.infyretailapp.entity.OrderEntity;
import com.infy.infyretailapp.entity.OrderProductEntity;
import com.infy.infyretailapp.entity.PrimaryKey;
import com.infy.infyretailapp.entity.ProductEntity;
import com.infy.infyretailapp.entity.UserEntity;
import com.infy.infyretailapp.resources.HibernateUtility;

public class OrderDAOImpl implements OrderDAO {

	/**
	 * Gets the orders corresponding to a user ID
	 * 
	 * @param userId
	 * @return the orders corresponding to the user ID
	 */
	@Override
	@SuppressWarnings("unchecked")
	public List<Order> showOrdersByUser(String userId) throws Exception {
		SessionFactory sessionFactory = null;
		Session session = null;
		List<Order> orderResult = new ArrayList<Order>();
		try {
			sessionFactory = HibernateUtility.createSessionFactory();
			session = sessionFactory.openSession();

			Criteria criteria = session.createCriteria(OrderEntity.class);
			criteria.add(Restrictions.eq("orderUser.userId", userId));
			criteria.addOrder(org.hibernate.criterion.Order.asc("orderAmount"));
			List<OrderEntity> orderList = criteria.list();

			for (OrderEntity oe : orderList) {
				Order order = new Order();
				order.setOrderId(oe.getOrderId());
				order.setOrderDate(oe.getOrderDate());
				order.setOrderAmount(oe.getOrderAmount());
				order.setNoOfItems(oe.getNoOfItems());
				User user = new User();
				user.setUserName(oe.getOrderUser().getUserName());
				order.setOrderUser(user);

				orderResult.add(order);
			}

			return orderResult;

		} catch (Exception e) {
			Logger logger = Logger.getLogger(this.getClass());
			logger.debug(e.getMessage(), e);
			throw new Exception("DAO.TECHINAL_ERROR");
		} finally {
			if (session.isOpen() || session != null) {
				session.close();
			}
		}
	}

	// added by FA3
	@SuppressWarnings("unchecked")
	public List<Order> showAllOrders() throws Exception {
		SessionFactory sessionFactory = null;
		Session session = null;
		List<Order> orderResult = new ArrayList<Order>();
		try {
			sessionFactory = HibernateUtility.createSessionFactory();
			session = sessionFactory.openSession();

			Query query = session.createQuery("Select oe from OrderEntity oe");

			List<OrderEntity> orderList = query.list();

			for (OrderEntity oe : orderList) {
				Order order = new Order();
				order.setOrderId(oe.getOrderId());
				order.setOrderDate(oe.getOrderDate());
				order.setOrderAmount(oe.getOrderAmount());
				order.setNoOfItems(oe.getNoOfItems());
				User user = new User();
				user.setUserName(oe.getOrderUser().getUserName());
				order.setOrderUser(user);

				orderResult.add(order);
			}

			return orderResult;

		} catch (Exception e) {
			Logger logger = Logger.getLogger(this.getClass());
			logger.debug(e.getMessage(), e);
			throw new Exception("DAO.TECHINAL_ERROR");
		} finally {
			if (session.isOpen() || session != null) {
				session.close();
			}
		}
	}

	/**
	 * Stores the order details in the database
	 * 
	 * @param order
	 * @return The order ID of the newly placed order
	 * @throws Exception
	 */
	@Override
	public Integer placeOrder(Order order) throws Exception {
		// Add to database

		SessionFactory sessionFactory = null;
		Session session = null;
		OrderEntity orderEntity = new OrderEntity();

		try {
			sessionFactory = HibernateUtility.createSessionFactory();
			session = sessionFactory.openSession();

			session.beginTransaction();
			UserEntity userEntity = (UserEntity) session.get(UserEntity.class,
					order.getOrderUser().getUserId());
			orderEntity.setNoOfItems(order.getNoOfItems());
			orderEntity.setOrderAmount(order.getOrderAmount());
			orderEntity.setOrderDate(order.getOrderDate());
			orderEntity.setOrderType(order.getOrderType().toString());
			orderEntity.setOrderUser(userEntity);
			session.save(orderEntity);

			for (OrderProduct orderProduct : order.getOrderProducts()) {

				OrderProductEntity orderProductEntity = new OrderProductEntity();
				PrimaryKey key = new PrimaryKey();
				key.setOrderId(orderEntity.getOrderId());
				key.setProductId(orderProduct.getProductId());
				orderProductEntity.setPrimaryKey(key);
				orderProductEntity.setQuantity(orderProduct.getQuantity());
				session.save(orderProductEntity);

			}
			session.getTransaction().commit();

		} catch (Exception e) {
			Logger logger = Logger.getLogger(this.getClass());
			logger.debug(e.getMessage(), e);
			throw new Exception("DAO.TECHINAL_ERROR");
		} finally {
			if (session.isOpen() || session != null) {
				session.close();
			}
		}

		return orderEntity.getOrderId();
	}

	@Override
	public Integer getOrderProductDetails(Integer orderId, Integer productId)
			throws Exception {

		SessionFactory sessionFactory = null;
		Session session = null;
		Integer quantity = null;
		try {
			sessionFactory = HibernateUtility.createSessionFactory();
			session = sessionFactory.openSession();

			session.beginTransaction();
			OrderEntity orderEntity = (OrderEntity) session.get(
					OrderEntity.class, orderId);
			ProductEntity productEntity = (ProductEntity) session.get(
					ProductEntity.class, productId);
			if (orderEntity != null && productEntity != null) {
				PrimaryKey primaryKey = new PrimaryKey();
				primaryKey.setOrderId(orderId);
				primaryKey.setProductId(productId);
				OrderProductEntity orderProductEntity = (OrderProductEntity) session
						.get(OrderProductEntity.class, primaryKey);
				quantity = orderProductEntity.getQuantity();
			}

		} catch (Exception e) {
			Logger logger = Logger.getLogger(this.getClass());
			logger.debug(e.getMessage(), e);
			throw new Exception("DAO.TECHINAL_ERROR");
		} finally {
			if (session.isOpen() || session != null) {
				session.close();
			}
		}

		return quantity;
	}

	@SuppressWarnings("unchecked")
	public List<Order> showOrdersByDate(Calendar date) throws Exception {
		SessionFactory sessionFactory = null;
		Session session = null;
		List<Order> orderResult = new ArrayList<Order>();
		try {
			sessionFactory = HibernateUtility.createSessionFactory();
			session = sessionFactory.openSession();

			/*
			 * Query query=session.createQuery(
			 * "Select oe from OrderEntity oe where oe.orderDate=?");
			 * query.setParameter(0, date); List<OrderEntity>
			 * orderList=query.list();
			 */

			Criteria criteria = session.createCriteria(OrderEntity.class);
			criteria.add(Restrictions.eq("orderDate", date));
			List<OrderEntity> orderList = criteria.list();

			for (OrderEntity oe : orderList) {
				Order order = new Order();
				order.setOrderId(oe.getOrderId());
				order.setOrderDate(oe.getOrderDate());
				order.setOrderAmount(oe.getOrderAmount());
				order.setNoOfItems(oe.getNoOfItems());
				User user = new User();
				user.setUserName(oe.getOrderUser().getUserName());
				order.setOrderUser(user);

				orderResult.add(order);
			}

			return orderResult;

		} catch (Exception e) {
			Logger logger = Logger.getLogger(this.getClass());
			logger.debug(e.getMessage(), e);
			throw new Exception("DAO.TECHINAL_ERROR");
		} finally {
			if (session.isOpen() || session != null) {
				session.close();
			}
		}
	}

	/*	*//**
	 * Gets the order details corresponding to an order ID
	 * 
	 * @param orderId
	 * @return the order details corresponding to the order ID
	 */
	@Override
	public Order viewOrder(Integer orderId) throws Exception {
		SessionFactory sessionFactory = null;
		Session session = null;
		Order order = null;
		try {
			sessionFactory = HibernateUtility.createSessionFactory();
			session = sessionFactory.openSession();

			OrderEntity orderEntity = (OrderEntity) session.get(
					OrderEntity.class, orderId);
			if (orderEntity != null) {
				order = new Order();
				order.setOrderId(orderEntity.getOrderId());
				order.setNoOfItems(orderEntity.getNoOfItems());
				order.setOrderAmount(orderEntity.getOrderAmount());
				order.setOrderDate(orderEntity.getOrderDate());
				order.setOrderType(orderEntity.getOrderType());

				User user = new User();
				user.setUserId(orderEntity.getOrderUser().getUserId());
				user.setUserName(orderEntity.getOrderUser().getUserName());
				order.setOrderUser(user);
			}
			return order;
		} catch (Exception e) {
			Logger logger = Logger.getLogger(this.getClass());
			logger.debug(e.getMessage(), e);
			throw new Exception("DAO.TECHINAL_ERROR");
		} finally {
			if (session.isOpen() || session != null) {
				session.close();
			}
		}

	}

	public List<Product> getProductNamesOrderedByUserId(String userId) throws Exception
	{
		SessionFactory sessionFactory = null;
		Session session = null;
		List<Integer> productIdList = new ArrayList<Integer>();
		List<Product> productList = new ArrayList<Product>();
		try {
			sessionFactory = HibernateUtility.createSessionFactory();
			session = sessionFactory.openSession();
			
			Query query = session.createQuery("from OrderEntity o where o.orderUser.userId=?");
			query.setParameter(0, userId);
			List<OrderEntity> orderEntityList = query.list();
			for (OrderEntity orderEntity : orderEntityList) {
				Query query2 = session.createQuery("select o.primaryKey.productId from OrderProductEntity o where o.primaryKey.orderId = ?");
				query2.setParameter(0, orderEntity.getOrderId());
				List<Integer> list = query2.list();
				productIdList.addAll(list);
			}
			
			if(!productIdList.isEmpty())
			{
				for (Integer productId : productIdList) {
					ProductEntity productEntity = (ProductEntity) session.get(ProductEntity.class, productId);
					Product product = new Product();
					product.setProductId(productEntity.getProductId());
					product.setName(productEntity.getName());
					productList.add(product);
				}
			}
			return productList;
		} catch (Exception e) {
			Logger logger = Logger.getLogger(this.getClass());
			logger.debug(e.getMessage(), e);
			throw new Exception("DAO.TECHINAL_ERROR");
		} finally {
			if (session.isOpen() || session != null) {
				session.close();
			}
		}
	}
}
