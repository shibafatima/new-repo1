package com.infy.infyretailapp.dao;

import java.util.List;

import com.infy.infyretailapp.bean.Offers;
import com.infy.infyretailapp.bean.RetailOutlet;

public interface RetailOfferDAO {
	
	public RetailOutlet addRetailOutletAndExistingOffer(RetailOutlet retailOutlet) throws Exception;
	public void addNewOffersToExistingRetail(RetailOutlet retailOutlet) throws Exception;
	public List<Offers> getAllOfferForRetail(Integer retailOutletId) throws Exception;
	public Integer deleteOffersForRetailOutlet(Integer retailOutletId,
			List<Offers> offers) throws Exception;

}
