package com.infy.infyretailapp.business.validator;

import java.util.Set;

import org.apache.log4j.Logger;

import com.infy.infyretailapp.bean.Order;
import com.infy.infyretailapp.bean.OrderProduct;

/**
 * Validates order
 * @author ETA
 */
public class OrderValidator {
	
	/**
	 * Validates the order
	 * @param order
	 * @return None
	 * @throws Exception
	 */
	public void validate(Order order) throws Exception
	{
		try
		{
			if(!isValidProductsQuantity(order.getOrderProducts()))
				throw new Exception("Validator.INVALID_ORDER_QUANTITY");
		}
		catch(Exception e)
		{
			Logger logger = Logger.getLogger(this.getClass());
			logger.error(e.getMessage(), e);
			throw e;
		}
	}

	/**
	 * Validates the ordered products quantity
	 * @param orderProducts, list of ordered products
	 * @return true if all the quantities are greater than zero
	 */
	public Boolean isValidProductsQuantity(Set<OrderProduct> orderProducts)
	{
		for(OrderProduct pr : orderProducts)
		{
			if(pr.getQuantity() <= 0) return false;
		}
		return true;
	}
}