package com.infy.infyretailapp.business.service;

import java.util.List;

import com.infy.infyretailapp.bean.User;
import com.infy.infyretailapp.dao.LoginDAO;
import com.infy.infyretailapp.resources.Factory;

public class LoginServiceImpl implements LoginService {
	public User getUserDetails(String userName, String password)
			throws Exception {
		LoginDAO loginDAO = Factory.createLoginDAO();
		List<User> userList = loginDAO.getUserDetails(userName, password);

		// find operation returns null when no entity is found as per the given
		// primary key value
		if (userList == null || userList.size() == 0) {
			throw new Exception("Service.INVALID_LOGIN");
		}
		// checking old password matches or not
		else if (!(userList.get(0).getPassword().equals(password))) {
			throw new Exception("Service.INVALID_LOGIN");
		}
		return userList.get(0);
	}

}
