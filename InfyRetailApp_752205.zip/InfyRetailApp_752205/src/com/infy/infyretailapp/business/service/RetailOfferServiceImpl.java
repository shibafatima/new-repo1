package com.infy.infyretailapp.business.service;

import java.util.List;

import org.apache.log4j.Logger;

import com.infy.infyretailapp.bean.Offers;
import com.infy.infyretailapp.bean.RetailOutlet;
import com.infy.infyretailapp.dao.RetailOfferDAO;
import com.infy.infyretailapp.resources.Factory;

public class RetailOfferServiceImpl implements RetailOfferService {

	@Override
	public RetailOutlet addRetailOutletAndExistingOffer(
			RetailOutlet retailOutlet) throws Exception {

		RetailOfferDAO dao = Factory.createRetailOfferDao();
		try {
			RetailOutlet outlet = dao
					.addRetailOutletAndExistingOffer(retailOutlet);
			if (outlet.getOffers().isEmpty()) {
				throw new Exception("Service.INVALID_OFFERS");
			}
			return outlet;
		} catch (Exception e) {
			if (e.getMessage().contains("Service")) {
				Logger logger = Logger.getLogger(this.getClass());
				logger.error(e.getMessage(), e);
			}
			throw e;
		}

	}

	@Override
	public void addNewOffersToExistingRetail(RetailOutlet retailOutlet)
			throws Exception {

		try {

			RetailOfferDAO dao = Factory.createRetailOfferDao();
			dao.addNewOffersToExistingRetail(retailOutlet);
		} catch (Exception e) {
			if (e.getMessage().contains("Service")) {
				Logger logger = Logger.getLogger(this.getClass());
				logger.error(e.getMessage(), e);
			}
			throw e;
		}

	}

	public List<Offers> getAllOfferForRetail(Integer retailOutletId)
			throws Exception {

		try {
			RetailOfferDAO dao = Factory.createRetailOfferDao();
			List<Offers> offerList = dao.getAllOfferForRetail(retailOutletId);
			if (offerList.isEmpty())
				throw new Exception("Service.NO_OFFERS_FOUND");
			return offerList;
		} catch (Exception e) {
			if (e.getMessage().contains("Service")) {
				Logger logger = Logger.getLogger(this.getClass());
				logger.error(e.getMessage(), e);
			}
			throw e;
		}
	}

	@Override
	public Integer deleteOffersForRetailOutlet(Integer retailOutletId,
			List<Offers> offers) throws Exception {

		RetailOfferDAO dao = Factory.createRetailOfferDao();
		try {
			Integer id = dao
					.deleteOffersForRetailOutlet(retailOutletId, offers);
			return id;
		} catch (Exception e) {
			if (e.getMessage().contains("Service")) {
				Logger logger = Logger.getLogger(this.getClass());
				logger.error(e.getMessage(), e);
			}
			throw e;
		}

	}

}
