package com.infy.infyretailapp.business.service;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.infy.infyretailapp.bean.Product;
import com.infy.infyretailapp.business.validator.ProductValidator;
import com.infy.infyretailapp.dao.ProductDAO;
import com.infy.infyretailapp.resources.Factory;

/**
 * Service class to execute business logic
 * 
 * @author ETA
 */

public class ProductServiceImpl implements ProductService {
	/**
	 * To get a product's details
	 * 
	 * @param productId
	 * @return The product details of the specified product
	 * @throws Exception
	 */
	@Override
	public Product findProduct(Integer productId) throws Exception {
		ProductDAO productDAO = Factory.createProductDAO();
		try {
			Product product = productDAO.findProduct(productId);
			if (product == null)
				throw new Exception("Service.PRODUCT_NOT_FOUND");
			return product;
		} catch (Exception e) {
			if (e.getMessage().contains("Service")) {
				Logger logger = Logger.getLogger(this.getClass());
				logger.error(e.getMessage(), e);
			}
			throw e;
		}
	}

	/**
	 * Adds product to the database
	 * 
	 * @param product
	 *            , the product to be added
	 * @return The product ID of the newly added product
	 * @throws Exception
	 */

	public List<Product> getProductByCategory(String category) throws Exception {
		ProductDAO productDAO = Factory.createProductDAO();
		try {
			List<Product> productList = productDAO
					.getProductByCategory(category);
			if (productList == null)
				throw new Exception("Service.PRODUCT_NOT_FOUND");
			return productList;
		} catch (Exception e) {
			if (e.getMessage().contains("Service")) {
				Logger logger = Logger.getLogger(this.getClass());
				logger.error(e.getMessage(), e);
			}
			throw e;
		}
	}

	@Override
	public Integer addProduct(Product product) throws Exception {
		try {
			// if validator is made, invoke it
			ProductDAO productDAO = Factory.createProductDAO();
			return productDAO.addProduct(product);
		} catch (Exception e) {
			if (e.getMessage().contains("Service")) {
				Logger logger = Logger.getLogger(this.getClass());
				logger.error(e.getMessage(), e);
			}
			throw e;
		}
	}

	@Override
	public void updateProduct(Product product) throws Exception {
		try {
			new ProductValidator().validate(product);
			ProductDAO productDAO = Factory.createProductDAO();
			productDAO.updateProduct(product);
		} catch (Exception e) {
			if (e.getMessage().contains("Service")) {
				Logger logger = Logger.getLogger(this.getClass());
				logger.error(e.getMessage(), e);
			}
			throw e;
		}
	}

	/**
	 * Removes the product from the database
	 * 
	 * @param productId
	 *            , product ID of the product to be removed
	 * @throws Exception
	 */
	@Override
	public void deleteProduct(Integer productId) throws Exception {
		try {
			ProductDAO productDAO = Factory.createProductDAO();
			Product product = productDAO.findProduct(productId);
			if (product == null) {
				throw new Exception("Service.PRODUCT_ALREADY_DELETED");
			}
			Integer id = productDAO.deleteProduct(productId);
			if (id == null) {
				throw new Exception("Service.PRODUCT_ALREADY_SOLD");
			}
		} catch (Exception e) {

			if (e.getMessage().contains("Service")) {
				Logger logger = Logger.getLogger(this.getClass());
				logger.error(e.getMessage(), e);
			}
			throw e;
		}
	}

	/**
	 * To get a product's details
	 * 
	 * @param productId
	 * @return The product details of the specified product
	 * @throws Exception
	 */
	@Override
	public Product getProductDetails(Integer productId) throws Exception {
		try {
			ProductDAO productDAO = Factory.createProductDAO();
			Product product = productDAO.getProductDetails(productId);
			if (product == null)
				throw new Exception("Service.PRODUCT_NOT_FOUND");
			return product;
		} catch (Exception e) {
			if (e.getMessage().contains("Service")) {
				Logger logger = Logger.getLogger(this.getClass());
				logger.error(e.getMessage(), e);
			}
			throw e;
		}
	}

	@Override
	public List<Product> getProductsInPriceRange(Double min, Double max)
			throws Exception {

		ProductDAO productDAO = Factory.createProductDAO();
		try {
			List<Product> allProducts = productDAO.getProductsInPriceRange(min,
					max);

			if (allProducts.isEmpty())
				throw new Exception("Service.NO_PRODUCT_FOUND");

			return allProducts;
		} catch (Exception e) {
			if (e.getMessage().contains("Service")) {
				Logger logger = Logger.getLogger(this.getClass());
				logger.error(e.getMessage(), e);
			}
			throw e;
		}
	}

	@Override
	public Long getCountOfProducts(String supplierId) throws Exception {

		ProductDAO dao = Factory.createProductDAO();
		Long count = null;
		try {
			count = dao.getCountOfProducts(supplierId);
			if (count == 0)
				throw new Exception("Service.NO_PRODUCTS_SUPPLIED");
		} catch (Exception e) {
			if (e.getMessage().contains("Service")) {
				Logger logger = Logger.getLogger(this.getClass());
				logger.error(e.getMessage(), e);
			}
			throw e;
		}
		return count;
	}

	@Override
	public void updateProductDetails(Product product) throws Exception {
		try {
			ProductDAO productDAO = Factory.createProductDAO();
			productDAO.updateProductDetails(product);
		} catch (Exception e) {
			if (e.getMessage().contains("Service")) {
				Logger logger = Logger.getLogger(this.getClass());
				logger.error(e.getMessage(), e);
			}
			throw e;
		}

	}

	@Override
	public List<Product> getAllProducts() throws Exception {
		List<Product> value = new ArrayList<Product>();
		try {
			ProductDAO productDAO = Factory.createProductDAO();
			value = productDAO.getAllProducts();
		} catch (Exception e) {
			if (e.getMessage().contains("Service")) {
				Logger logger = Logger.getLogger(this.getClass());
				logger.error(e.getMessage(), e);
			}
			throw e;
		}
		return value;
	}

	@Override
	public List<String> getCategoryDetails() throws Exception {
		List<String> value = new ArrayList<String>();
		try {
			ProductDAO productDAO = Factory.createProductDAO();
			value = productDAO.getCategoryDetails();
		} catch (Exception e) {
			if (e.getMessage().contains("Service")) {
				Logger logger = Logger.getLogger(this.getClass());
				logger.error(e.getMessage(), e);
			}
			throw e;
		}
		return value;
	}

	@Override
	public List<String> getSupplierIdList() throws Exception {
		List<String> value = new ArrayList<String>();
		try {
			ProductDAO productDAO = Factory.createProductDAO();
			value = productDAO.getSupplierIdList();
		} catch (Exception e) {
			if (e.getMessage().contains("Service")) {
				Logger logger = Logger.getLogger(this.getClass());
				logger.error(e.getMessage(), e);
			}
			throw e;
		}
		return value;
	}

}
