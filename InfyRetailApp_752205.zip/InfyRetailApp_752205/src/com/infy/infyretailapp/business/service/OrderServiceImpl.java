package com.infy.infyretailapp.business.service;

import java.util.Calendar;
import java.util.List;
import java.util.Set;

import org.apache.log4j.Logger;

import com.infy.infyretailapp.bean.Order;
import com.infy.infyretailapp.bean.OrderProduct;
import com.infy.infyretailapp.bean.OrderType;
import com.infy.infyretailapp.bean.Product;
import com.infy.infyretailapp.bean.UserRole;
import com.infy.infyretailapp.business.validator.OrderValidator;
import com.infy.infyretailapp.dao.OrderDAO;
import com.infy.infyretailapp.resources.Factory;

/**
 * Service class to execute business logic
 * 
 * @author ETA
 */

public class OrderServiceImpl implements OrderService {
	/*	*//**
	 * Stores the order details in the database
	 * 
	 * @param order
	 * @return The order ID of the newly placed order
	 * @throws Exception
	 */
	/*
	*//**
	 * Gets the order details corresponding to an order ID
	 * 
	 * @param orderId
	 * @return the order details corresponding to the order ID
	 * @throws Exception
	 */
	@Override
	public Order viewOrder(Integer orderId) throws Exception {
		OrderDAO dao = Factory.createOrderDAO();
		Order order = null;
		try {
			order = dao.viewOrder(orderId);
			if (order == null)
				throw new Exception("Service.ORDER_NOT_FOUND");
		} catch (Exception e) {
			if (e.getMessage().contains("Service")) {
				Logger logger = Logger.getLogger(this.getClass());
				logger.error(e.getMessage(), e);
			}
			throw e;
		}
		return order;
	}

	/**
	 * Stores the order details in the database
	 * 
	 * @param order
	 * @return The order ID of the newly placed order
	 * @throws Exception
	 */
	@Override
	public Integer placeOrder(Order order) throws Exception {

		OrderDAO dao = Factory.createOrderDAO();
		try {
			new OrderValidator().validate(order);
			checkProductsAvailability(order.getOrderProducts());
			order.setOrderType(String.valueOf(determineOrderType(order
					.getOrderUser().getUserId())));
			order.setNoOfItems(calculateNoOfItems(order.getOrderProducts()));
			order.setOrderAmount(calculateAmount(order.getOrderUser()
					.getUserId(), order.getOrderProducts()));
			Calendar calendar = Calendar.getInstance();
			order.setOrderDate(calendar);
			return dao.placeOrder(order);
		} catch (Exception e) {
			if (e.getMessage().contains("Service")) {
				Logger logger = Logger.getLogger(this.getClass());
				logger.error(e.getMessage(), e);
			}
			throw e;
		}
	}

	/**
	 * To check the availability of products
	 * 
	 * @param List
	 *            of ordered products
	 * @throws Exception
	 */
	@Override
	public void checkProductsAvailability(Set<OrderProduct> orderProducts)
			throws Exception {
		ProductService service = Factory.createProductService();
		for (OrderProduct pr : orderProducts) {
			Integer qty = service.findProduct(pr.getProductId()).getQuantity();
			if (pr.getQuantity() > qty)
				throw new Exception("Service.NOT_ENOUGH_PRODUCTS");
		}
	}

	/**
	 * To calculate the total number of items for an order
	 * 
	 * @param List
	 *            of ordered products
	 * @return Total number of items
	 */
	@Override
	public Integer calculateNoOfItems(Set<OrderProduct> orderProducts) {
		Integer total = 0;
		for (OrderProduct product : orderProducts) {
			total += product.getQuantity();
		}
		return total;
	}

	/**
	 * To determine the type of order based on user ID
	 * 
	 * @param User
	 *            ID
	 * @return Order type
	 * @throws Exception
	 */
	@Override
	public OrderType determineOrderType(String userId) throws Exception {
		UserService userService = Factory.createUserService();

		if (userService.findUser(userId).getUserRole()
				.equals(UserRole.CUSTOMER))
			return OrderType.CUSTOMER;
		else
			return OrderType.SUPPLIER;
	}

	/**
	 * To calculate the total amount of an order
	 * 
	 * @param User
	 *            ID, List of ordered products
	 * @return Total amount
	 */
	@Override
	public Double calculateAmount(String userId, Set<OrderProduct> orderProducts)
			throws Exception {
		Double amount = 0.0;
		ProductService productService = Factory.createProductService();
		UserService userService = Factory.createUserService();

		if (userService.findUser(userId).getUserRole()
				.equals(UserRole.CUSTOMER)) {
			for (OrderProduct product : orderProducts) {
				Double price = productService.findProduct(
						product.getProductId()).getSellingPrice();
				Float discount = productService.findProduct(
						product.getProductId()).getDiscount();
				amount += ((price - (price * discount / 100)) * product
						.getQuantity());
			}
		} else {
			for (OrderProduct product : orderProducts) {
				amount += (productService.findProduct(product.getProductId())
						.getCost() * product.getQuantity());
			}
		}
		return amount;
	}

	@Override
	public Integer getOrderProductDetails(Integer orderId, Integer productId)
			throws Exception {

		OrderDAO dao = Factory.createOrderDAO();
		Integer quantity = dao.getOrderProductDetails(orderId, productId);
		if (quantity == null) {
			throw new Exception("Service.INVALID_ORDER_ID_PRODUCT_ID");
		}
		return quantity;
	}

	/**
	 * Gets the orders corresponding to a user ID
	 * 
	 * @param userId
	 * @return the orders corresponding to the user ID
	 * @throws Exception
	 */
	@Override
	public List<Order> showOrdersByUser(String userId) throws Exception {
		OrderDAO dao = Factory.createOrderDAO();
		try {
			List<Order> orderList = dao.showOrdersByUser(userId);
			if (orderList.isEmpty())
				throw new Exception("Service.NO_ORDER_FOUND");
			return orderList;
		} catch (Exception e) {
			if (e.getMessage().contains("Service")) {
				Logger logger = Logger.getLogger(this.getClass());
				logger.error(e.getMessage(), e);
			}
			throw e;
		}
	}

	/**
	 * Gets all the orders based on order date
	 * 
	 * @param date
	 * @return All orders
	 * @throws Exception
	 */
	@Override
	public List<Order> showOrdersByDate(Calendar date) throws Exception {
		OrderDAO dao = Factory.createOrderDAO();
		try {
			List<Order> orderList = dao.showOrdersByDate(date);

			if (orderList.isEmpty())
				throw new Exception("Service.NO_ORDER_FOUND");
			return orderList;
		} catch (Exception e) {
			if (e.getMessage().contains("Service")) {
				Logger logger = Logger.getLogger(this.getClass());
				logger.error(e.getMessage(), e);
			}
			throw e;
		}
	}

	@Override
	public List<Order> showAllOrders() throws Exception {

		OrderDAO dao = Factory.createOrderDAO();
		try {
			List<Order> orderList = dao.showAllOrders();

			if (orderList.isEmpty())
				throw new Exception("Service.NO_ORDER_FOUND");
			return orderList;
		} catch (Exception e) {
			if (e.getMessage().contains("Service")) {
				Logger logger = Logger.getLogger(this.getClass());
				logger.error(e.getMessage(), e);
			}
			throw e;
		}
	}

	public List<Product> getProductNamesOrderedByUserId(String userId) throws Exception
	{
		try
		{
			List<Product> productList = Factory.createOrderDAO().getProductNamesOrderedByUserId(userId);
			if(productList==null || productList.isEmpty())
			{
				throw new Exception("OrderService.NO_PRODUCTS_ORDERED");
			}
			return productList;
		} catch (Exception e) {
			if (e.getMessage().contains("Service")) {
				Logger logger = Logger.getLogger(this.getClass());
				logger.error(e.getMessage(), e);
			}
			throw e;
		}
	}
}
