package com.infy.infyretailapp.business.service;

import java.util.List;

import com.infy.infyretailapp.bean.Offers;
import com.infy.infyretailapp.bean.RetailOutlet;


public interface RetailOfferService {
	
	

	public RetailOutlet addRetailOutletAndExistingOffer(RetailOutlet retailOutlet) throws Exception;
	
	public void addNewOffersToExistingRetail(RetailOutlet retailOutlet) throws Exception;
	
	public List<Offers> getAllOfferForRetail(Integer retailOutletId) throws Exception;


	public Integer deleteOffersForRetailOutlet(Integer retailOutletId,
			List<Offers> offers) throws Exception;

}
