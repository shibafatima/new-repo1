package com.infy.infyretailapp.business.service;

import java.util.Calendar;
import java.util.List;
import java.util.Set;

import com.infy.infyretailapp.bean.Order;
import com.infy.infyretailapp.bean.OrderProduct;
import com.infy.infyretailapp.bean.OrderType;
import com.infy.infyretailapp.bean.Product;

public interface OrderService
{
	public Order viewOrder(Integer orderId) throws Exception;
	public List<Order> showOrdersByDate(Calendar date) throws Exception;
	public List<Order> showOrdersByUser(String userId) throws Exception;
	public Integer placeOrder(Order order) throws Exception;
	public Integer getOrderProductDetails(Integer orderId, Integer productId)
			throws Exception;

	
	
	public void checkProductsAvailability(Set<OrderProduct> orderProducts) throws Exception;
	public Integer calculateNoOfItems(Set<OrderProduct> orderProducts);
	public Double calculateAmount(String userId, Set<OrderProduct> orderProducts) throws Exception;
	public OrderType determineOrderType(String userId) throws Exception;
	
	public List<Order> showAllOrders() throws Exception;
	public List<Product> getProductNamesOrderedByUserId(String userId) throws Exception;
}

