package com.infy.infyretailapp.business.service;

import com.infy.infyretailapp.bean.User;

public interface LoginService {

	User getUserDetails(String userName, String password) throws Exception;

	
	
}
