package com.infy.infyretailapp.business.service;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import org.apache.log4j.Logger;

import com.infy.infyretailapp.bean.Feedback;
import com.infy.infyretailapp.bean.User;
import com.infy.infyretailapp.business.validator.UserValidator;
import com.infy.infyretailapp.dao.UserDAO;
import com.infy.infyretailapp.resources.Factory;

/**
 * Service class to execute business logic
 * 
 * @author ETA
 */

public class UserServiceImpl implements UserService {
	
	/**
	 * Submits the feedback written by the user for a product
	 * @param feedback
	 * 
	 * @return feedbackId
	 */
	@Override
	public Integer submitFeedback(Feedback feedback) throws Exception {
		// TODO Auto-generated method stub
		try
		{
			feedback.setFeedbackDate(Calendar.getInstance());
			return Factory.createUserDAO().submitFeedback(feedback);
		}
		catch (Exception e) {
			if (e.getMessage().contains("Service")) {
				Logger logger = Logger.getLogger(this.getClass());
				logger.error(e.getMessage(), e);
			}
			throw e;
		}
	}
	
	/**
	 * Adds user to the database
	 * 
	 * @param user
	 *            , the user to be added
	 * @return The user ID of the newly added user
	 * @throws Exception
	 */
	@Override
	public String addUser(User user) throws Exception {
		UserValidator validator = new UserValidator();
		UserDAO dao = Factory.createUserDAO();
		try {
			// Check the business rules
			validator.isValidEmail(user.getEmail());
			validator.isValidPassword(user.getPassword());

			// Add the user
			return dao.addUser(user);
		} catch (Exception e) {
			if (e.getMessage().contains("Service")) {
				Logger logger = Logger.getLogger(this.getClass());
				logger.error(e.getMessage(), e);
			}
			throw e;
		}
	}

	/**
	 * To get a user's details
	 * 
	 * @param userId
	 * @return The user details of the specified user
	 * @throws Exception
	 */
	@Override
	public User findUser(String userId) throws Exception {
		UserDAO dao = Factory.createUserDAO();
		try {
			User user = dao.findUser(userId);

			if (user == null)
				throw new Exception("Service.USER_NOT_FOUND");
			return user;
		} catch (Exception e) {
			if (e.getMessage().contains("Service")) {
				Logger logger = Logger.getLogger(this.getClass());
				logger.error(e.getMessage(), e);
			}
			throw e;
		}
	}

	public List<User> getAllUsers(String userRole) throws Exception {
		// Get the user details from DAO
		UserDAO dao = Factory.createUserDAO();
		List<User> allUsers;
		try {
			allUsers = dao.getAllUsers(userRole);
			// If the list has no users, throw an exception with the
			// corresponding message
			if (allUsers.isEmpty())
				throw new Exception("Service.NO_USER_FOUND");
		} catch (Exception e) {
			if (e.getMessage().contains("Service")) {
				Logger logger = Logger.getLogger(this.getClass());
				logger.error(e.getMessage(), e);
			}
			throw e;
		}
		return allUsers;
	}

	/**
	 * Updates existing user in the database
	 * 
	 * @param user
	 *            , the user to be updated
	 * @throws Exception
	 */
	@Override
	public void updateUser(User user) throws Exception {
		UserValidator validator = new UserValidator();
		UserDAO dao = Factory.createUserDAO();
		try {
			// Check the business rules
			validator.isValidEmail(user.getEmail());

			// Update user details
			dao.updateUser(user);
		} catch (Exception e) {
			if (e.getMessage().contains("Service")) {
				Logger logger = Logger.getLogger(this.getClass());
				logger.error(e.getMessage(), e);
			}
			throw e;
		}
	}

	/**
	 * Changes existing user's password in the database
	 * 
	 * @param userId
	 *            , oldPassword, newPassword
	 * @throws Exception
	 */
	@Override
	public void changePassword(String userId, String oldPassword,
			String newPassword) throws Exception {
		UserValidator validator = new UserValidator();
		UserDAO dao = Factory.createUserDAO();
		try {
			if (oldPassword.equalsIgnoreCase(newPassword))
				throw new Exception("Service.SAME_NEW_PASSWORD");
			else {
				// Check the business rules
				validator.isValidPassword(newPassword);

				// Update user details
				dao.changePassword(userId, oldPassword, newPassword);
			}
		} catch (Exception e) {
			if (e.getMessage().contains("Service")) {
				Logger logger = Logger.getLogger(this.getClass());
				logger.error(e.getMessage(), e);
			}
			throw e;
		}
	}

	/**
	 * Removes the user from the database
	 * 
	 * @param userId
	 *            , user ID of the user to be removed
	 * @throws Exception
	 */
	@Override
	public void deactivateUser(String userId) throws Exception {
		UserDAO dao = Factory.createUserDAO();
		try {
			dao.deactivateUser(userId);
		} catch (Exception e) {
			if (e.getMessage().contains("Service")) {
				Logger logger = Logger.getLogger(this.getClass());
				logger.error(e.getMessage(), e);
			}
			throw e;
		}
	}

	@Override
	public void updateUserDetails(User user) throws Exception {
		UserValidator validator = new UserValidator();
		UserDAO dao = Factory.createUserDAO();
		try {
			// Check the business rules
			validator.isValidEmail(user.getEmail());

			// Update user details
			dao.updateUserDetails(user);
		} catch (Exception e) {
			if (e.getMessage().contains("Service")) {
				Logger logger = Logger.getLogger(this.getClass());
				logger.error(e.getMessage(), e);
			}
			throw e;
		}

	}
	
	
	@Override
	public List<Feedback> getAllFeedback() throws Exception {
		
		List<Feedback> feedbacks=new ArrayList<>();
		try{
			UserDAO dao = Factory.createUserDAO();
			feedbacks = dao.getAllFeedback();
			if(feedbacks.isEmpty()) {
				throw new Exception("UserService.NO_FEEDBACK_SUBMITTED");
			}
		}
		catch (Exception e) {
			if (e.getMessage().contains("Service")) {
				Logger logger = Logger.getLogger(this.getClass());
				logger.error(e.getMessage(), e);
			}
			throw e;
		}
		return feedbacks;
	}
	
	

	@Override
	public List<User> getOnlyUsers() throws Exception {

		// Get the user details from DAO
		UserDAO dao = Factory.createUserDAO();
		List<User> allUsers;
		try {
			allUsers = dao.getOnlyUsers();
			if (allUsers.isEmpty())
				throw new Exception("Service.NO_USER_FOUND");
		} catch (Exception e) {
			if (e.getMessage().contains("Service")) {
				Logger logger = Logger.getLogger(this.getClass());
				logger.error(e.getMessage(), e);
			}
			throw e;
		}
		return allUsers;
	}

}


///////@Override
	public List<Feedback> getAllFeedback() throws Exception{
		List<Feedback>returnList=new ArrayList<Feedback>();
		try{
			UserDAO dao = Factory.createUserDAO();
			returnList=dao.getAllFeedback();
			if(returnList.isEmpty()){
				throw new Exception("UserService.NO_FEEDBACK_SUBMITTED");
			}
			else{
				return returnList;
			}
		}
		catch (Exception e) {
			if (e.getMessage().contains("Service")) {
				Logger logger = Logger.getLogger(this.getClass());
				logger.error(e.getMessage(), e);
			}
			throw e;
		}
		

}/////////