infyRetail.controller(
		"UserProfileController",
		function($scope, $http, $cookies) {
			$scope.getUserName = function() {
				if($cookies.get('name')==null){
					window.location="../../error.html";
				}
				else{
					$scope.username = $cookies.get('name');
				}
			}
			
			$scope.logout = function() {
				$cookies.remove('Id');
				$cookies.remove('name');
				$cookies.remove('role');
				window.location="../../index.html";
			}
		});