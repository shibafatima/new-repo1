
// -----------------------REGISTERING THE APPLICATION AND DEPENDENCIES-----------------------

var infyRetails = angular.module("Filters", []);


// -------------------------REGISTERING THE FILTERS WITH THE APPLICATION---------------------
infyRetails.filter('UserStatusFilter', function() {

	return function(value) {
		if(value){
			if (value == 'D')
				return 'Deactive';
			else if (value == 'A')
				return 'Active';
		}
		return value;
		
	}

});

infyRetails.filter('CalendarFilter', function() {

	return function(dateValue) {
		dateValue=new Date(dateValue);
		if(dateValue){
			var month = dateValue.getMonth();
			var monthStr = null;
			if(month == 0)
				monthStr = 'Jan';
			if(month == 1)
				monthStr = 'Feb';
			if(month == 2)
				monthStr = 'Mar';
			if(month == 3)
				monthStr = 'Apr';
			if(month == 4)
				monthStr = 'May';
			if(month == 5)
				monthStr = 'Jun';
			if(month == 6)
				monthStr = 'Jul';
			if(month == 7)
				monthStr = 'Aug';
			if(month == 8)
				monthStr = 'Sep';
			if(month == 9)
				monthStr = 'Oct';
			if(month == 10)
				monthStr = 'Nov';
			if(month == 11)
				monthStr = 'Dec';
			return dateValue.getDate() + "-" + monthStr + "-" + dateValue.getFullYear();
		}
		return dateValue;
	}

});