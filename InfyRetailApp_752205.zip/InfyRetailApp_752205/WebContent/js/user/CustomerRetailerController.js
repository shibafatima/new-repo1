infyRetail
		.controller(
				"CustomerFeedbackController",
				function($scope, $http, $cookies) {
				$scope.customerFeedbackForm = {};
				$scope.customerFeedbackForm.rating = "";
				$scope.customerFeedbackForm.message = null;
				
				$scope.ratingList = ['Very Good','Good','Average','Poor','Very Poor'];
				$scope.productNameList = null;
				$scope.productList = null;
				
				$scope.generateProductNameList = function() {
					var responsePromise = $http.get(URI + "OrderAPI" + "/getProductNamesOrderedByUserId");
					responsePromise
							.then(
									function(response) {
										$scope.productNameList = response.data;
										$scope.customerFeedbackForm.message = null;
									},
									function(response) {
										$scope.productNameList = null;
										$scope.customerFeedbackForm.message = response.data.message;
									});
					
				}
				
				
				$scope.customerFeedbackForm.submitFeedback = function() {
					$scope.customerFeedbackForm.productId = parseInt($scope.customerFeedbackForm.productId, 10);
						var data = angular.toJson($scope.customerFeedbackForm);
						var responsePromise = $http.post(URI + "UserAPI"
								+ "/submitFeedback", data);
						
						responsePromise
						.then(
								function(response){
									$scope.customerFeedbackForm.rating = toString(response.data.rating);
									$scope.customerFeedbackForm.message = response.data.message;
								},
								function(response){
									$scope.customerFeedbackForm.message = response.data.message;
								}
								)
								
					}
				
				
				});

infyRetail
		.controller(
				"ViewUpdateUserController",
				function($scope, $http, $cookies) {

					$scope.userDetailsForm = {};

					$scope.userDetailsForm.getUserDetails = function() {
						$scope.flagBasicDetails = false;
						$scope.flagFetchedDetails = false;
						if ($scope.userDetailsForm.choice == 'view') {
							$scope.flagBasicDetails = true;
						}
						if ($scope.userDetailsForm.choice == 'update') {
							$scope.flagFetchedDetails = true;
						}
						var responsePromise = $http.get(URI + "UserAPI"
								+ "/userDetailsById");

						responsePromise
								.then(
										function(response) {
												$scope.userDetailsForm.mobileNumber = response.data.mobileNumber;
												$scope.userDetailsForm.email = response.data.email;
												$scope.userDetailsForm.userId = response.data.userId;
												$scope.userDetailsForm.message = null;
										},
										function(response) {
											$scope.userDetailsForm.message = response.data.message;
											$scope.userDetailsForm.mobileNumber = null;
											$scope.userDetailsForm.email = null;
											$scope.userDetailsForm.userId = null;
										});
					}

					$scope.userDetailsForm.updateUserDetails = function() {

						$scope.userDetailsForm.message = null;
						var data = angular.toJson($scope.userDetailsForm);
						var responsePromise = $http.put(URI + "UserAPI", data);
						responsePromise
								.then(
										function(response) {
											$scope.userDetailsForm.message = response.data.message;
										},
										function(response) {
											$scope.userDetailsForm.message = response.data.message;
										});

					}
				});

infyRetail
		.controller(
				"PlaceOrderController",
				function($scope, $http, $cookies) {

					$scope.placeOrderForm = {};
					$scope.productList = null;
					$scope.generateProductIdList = function() {
						var responsePromise = $http.get(URI + "ProductAPI");

						responsePromise
								.then(
										function(response) {
											$scope.productIdList = response.data;
											$scope.placeOrderForm.message = null;
										},
										function(response) {
											$scope.productIdList = null;
											$scope.placeOrderForm.message = response.data.message;
										});
					}
					$scope.placeOrderForm.getProductById = function() {
						if ($scope.placeOrderForm.productId == null) {
							$scope.flag = false;
						} else {
							$scope.placeOrderForm.message = null;
							var data = angular.fromJson($scope.placeOrderForm);
							data.productId=parseInt(data.productId);
							var responsePromise = $http.post(URI + "ProductAPI"
									+ "/productDetailsById", data);
							responsePromise
									.then(
											function(response) {
												$scope.placeOrderForm.message = null;
												$scope.flag = true;
												$scope.placeOrderForm.productId = response.data.productId;
												$scope.placeOrderForm.productName = response.data.name;
												$scope.placeOrderForm.price = response.data.sellingPrice;
												$scope.placeOrderForm.quantity = response.data.quantity;
											},
											function(response) {
												$scope.flag = false;
												$scope.placeOrderForm.message = response.data.message;
												$scope.placeOrderForm.productId = null;
												$scope.placeOrderForm.productName = null;
												$scope.placeOrderForm.price = null;
												$scope.placeOrderForm.quantity = null;
											});

						}
					}
					$scope.placeOrderForm.placeOrder = function() {
						$scope.placeOrderForm.message = null;
						var data = angular.toJson($scope.placeOrderForm);
						var responsePromise = $http
								.post(URI + "OrderAPI", data);
						responsePromise
								.then(
										function(response) {
											$scope.placeOrderForm.message = response.data.message;
										},
										function(response) {
											$scope.placeOrderForm.message = response.data.message;
										});

					}
				});

infyRetail.controller("ViewUserOrdersController", function($scope, $http,
		$cookies) {
	$scope.orderList = null;
	$scope.viewOrderList = function() {
		var responsePromise = $http.get(URI + "OrderAPI" + "/ordersByUser");

		responsePromise.then(function(response) {
			$scope.orderList = response.data;
			for(var i = 0; i < $scope.orderList.length; i++){
				$scope.orderList[i].orderDate = new Date($scope.orderList[i].orderDate);
			}
			$scope.message = null;
		}, function(response) {
			$scope.orderList = null;
			$scope.message = response.data.message;
		});
	}

});