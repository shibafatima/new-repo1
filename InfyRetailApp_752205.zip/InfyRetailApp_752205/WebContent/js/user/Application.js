
var URI = getURI();



// -----------------------REGISTERING THE APPLICATION AND DEPENDENCIES-----------------------

var infyRetail = angular.module("Application", [ 'ngRoute','ngCookies','Filters']);

infyRetail.config(function($httpProvider) {
	$httpProvider.defaults.headers.post['Content-Type'] = "application/json; charset=UTF-8";
	$httpProvider.defaults.headers.post['Data-Type'] = "json";
});


// ----------------------CONFIGURING THE APPLICATION------------------------

infyRetail.config([ '$routeProvider', function($routeProvider) {
	$routeProvider.when('/', {
		controller : 'LogoutController'
	}).when('/ShowProduct', {
		templateUrl : '../../partials/admin/ShowProductsByRange.html',
		controller : 'AdminShowProductController'
	}).when('/ShowOrder', {
		templateUrl : '../../partials/admin/AdminShowAllOrders.html',
		controller : 'AdminShowOrdersController'
	}).when('/ViewProducts', {
		templateUrl : '../../partials/admin/AdminViewAllProducts.html',
		controller : 'ViewAllProductsController'
	}).when('/ViewUser', {
		templateUrl : '../../partials/admin/AdminViewUser.html',
		controller : 'AdminViewUserController'
	}).when('/Feedback', {
		templateUrl : '../../partials/customer_retailer/CustomerFeedback.html',
		controller : 'CustomerFeedbackController'
	}).when('/DeleteUser', {
		templateUrl : '../../partials/admin/AdminDeactivateUser.html',
		controller : 'AdminDeactivateUserController'
	}).when('/AddProduct', {
		templateUrl : '../../partials/admin/AdminAddProduct.html',
		controller : 'AdminAddProductController'
	}).when('/UpdateProduct', {
		templateUrl : '../../partials/admin/AdminUpdateProduct.html',
		controller : 'AdminUpdateProductController'
	}).when('/DeleteProduct', {
		templateUrl : '../../partials/admin/AdminDeleteProduct.html',
		controller : 'AdminDeleteProductController'
	//----------
	}).when('/ProductFeedback', {
				templateUrl : '../../partials/admin/ProductFeedback.html',
				controller : 'AdminShowAllFeedbackController'
	}).when('/ViewUpdateUser', {
		templateUrl : '../../partials/customer_retailer/CustomerRetailerUpdateUserProfile.html',
		controller : 'ViewUpdateUserController'
	}).when('/ViewOrder', {
		templateUrl : '../../partials/customer_retailer/CustomerRetailerViewOrders.html',
		controller : 'ViewUserOrdersController'
	}).when('/PlaceOrder', {
		templateUrl : '../../partials/customer_retailer/CustomerRetailerPlaceOrder.html',
		controller : 'PlaceOrderController'
	}).otherwise({
		redirectTo : '/'
	});
} ]);

