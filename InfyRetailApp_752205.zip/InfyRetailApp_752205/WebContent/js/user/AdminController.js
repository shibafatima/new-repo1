

infyRetail.controller("AdminShowProductController", function($scope, $http) {

	$scope.showProductForm = {};
	$scope.productList = null;
	$scope.flagShow = false;
	$scope.showProductForm.message = null;

	$scope.showProductForm.getProductDetails = function() {
		$scope.showProductForm.message = null;
		var data = angular.toJson($scope.showProductForm);
		var responsePromise = $http.post(URI + "ProductAPI"
				+ "/productsInPriceRange", data);
		responsePromise.then(function(response) {
				$scope.showProductForm.message = null;
				$scope.flagShow = true;
				$scope.showProductForm.productList = response.data;
		}, function(response) {
			$scope.flagshow = false;
			$scope.showProductForm.message = response.data.message;
			$scope.showProductForm.productList = null;
		});

	}
});

infyRetail.controller("ViewAllProductsController", function($scope, $http) {
	$scope.allProductList = null;
	$scope.fetchAllProducts = function() {
		var responsePromise = $http
				.get(URI + "ProductAPI" + "/allProductsList");

		responsePromise.then(function(response) {
			$scope.allProductList = response.data;
			$scope.message = null;
		}, function(response) {
			$scope.allProductList = null;
			$scope.message = response.data.message;
		});
	}
});

infyRetail.controller("AdminShowOrdersController", function($scope, $http) {
	$scope.allOrderList = null;
	$scope.viewAllOrderList = function() {

		var responsePromise = $http.get(URI + "OrderAPI");

		responsePromise.then(function(response) {
			$scope.allOrderList = response.data;
			for(var i = 0; i < $scope.allOrderList.length; i++){
				$scope.allOrderList[i].orderDate = new Date($scope.allOrderList[i].orderDate);
			}
			$scope.message = null;
		}, function(response) {
			$scope.allOrderList = null;
			$scope.message = response.data.message;
		});
	}
});

infyRetail
		.controller(
				"AdminViewUserController",
				function($scope, $http) {

					$scope.viewUserForm = {};

					$scope.generateUserIdList = function() {
						var responsePromise = $http.get(URI + "UserAPI"
								+ "/userIdList");

						responsePromise.then(function(response) {
							$scope.userIdList = response.data;
							$scope.viewUserForm.message = null;
						}, function(response) {
							$scope.userIdList = null;
							$scope.viewUserForm.message = response.data.message;
						});
					}

					$scope.viewUserForm.getUserDetailsById = function() {
						if ($scope.viewUserForm.userId == null) {
							$scope.flag = false;
						} else {
							$scope.viewUserForm.message = null;
							var data = angular.toJson($scope.viewUserForm);
							var responsePromise = $http.post(URI + "UserAPI",
									data);
							responsePromise
									.then(
											function(response) {
													$scope.flag = true;
													$scope.viewUserForm.mobileNumber = response.data.mobileNumber;
													$scope.viewUserForm.dateOfBirth = response.data.dateOfBirth;
													$scope.viewUserForm.dateOfBirth = new Date($scope.viewUserForm.dateOfBirth);
													$scope.viewUserForm.userId = response.data.userId;
													$scope.viewUserForm.userName = response.data.userName;
													$scope.viewUserForm.userType = response.data.userType;
													$scope.viewUserForm.gender = response.data.gender;
													$scope.viewUserForm.message = null;
											},
											function(response) {
												$scope.flag = false;
												$scope.viewUserForm.mobileNumber = null;
												$scope.viewUserForm.dateOfBirth = null;
												$scope.viewUserForm.userId = null;
												$scope.viewUserForm.userName = null;
												$scope.viewUserForm.userType = null;
												$scope.viewUserForm.gender = null;
												$scope.viewUserForm.message = response.data.message;
											});
						}
					}

				});

infyRetail
		.controller(
				"AdminDeactivateUserController",
				function($scope, $http, $route) {

					$scope.fetchAllUsers = function() {
						var responsePromise = $http.get(URI + "UserAPI"
								+ "/userList");

						responsePromise.then(function(response) {
							$scope.allUsersList = response.data;
							$scope.message = null;
						}, function(response) {
							$scope.allUsersList = null;
							$scope.message = response.data.message;
						});
					}

					$scope.deactivateUsers = function(item) {
						$scope.message = null;
						var responsePromise = $http.post(URI + "UserAPI/deactivateUser/" + item.userId);

						responsePromise
								.then(
										function(response) {
												$scope.message = response.data.message;
												$route.reload();
										},
										function(response) {
											$scope.message = response.data.message;
										});
					}
				});


infyRetail.controller("AdminShowAllFeedbackController" , function($scope,$http) {
	$scope.message = null;
	$scope.getAllFeedback = function(){
		$scope.feedbackList=null;
		

		var responsePromise = $http.get(URI + "UserAPI"
				+ "/getAllFeedback");
		responsePromise.then(function(response) {
			$scope.feedbackList = response.data;
			$scope.message = null;
		}, function(response) {
			$scope.feedbackList = null;
			$scope.message = response.data.message;
		});
	}
		$scope.getProductDetails = function(productId) {
			$scope.product = {};
			$scope.flag=false;
			$scope.product.productId= productId;
			var data = angular.toJson($scope.product);
			var responsePromise = $http.post(URI + "ProductAPI"+"/productDetailsById",
					data);
			responsePromise
			.then(
					function(response) {
						$scope.flag=true;
						$scope.product.productId=response.data.productId;
						$scope.product.productName=response.data.name;
						$scope.product.cost=response.data.cost;
						$scope.product.sellingPrice = response.data.sellingPrice;
						$scope.product.quantity = response.data.quantity;
						$scope.product.specification = response.data.specification;
						$scope.message = null;
					}, function(response) {
					
						$scope.message = response.data.message;
					});
		}
	});
	
	




infyRetail
		.controller(
				"AdminUpdateProductController",
				function($scope, $http) {

					$scope.updateProductForm = {};
					$scope.productList = null;

					$scope.generateProductIdList = function() {
						var responsePromise = $http.get(URI + "ProductAPI");

						responsePromise
								.then(
										function(response) {
											$scope.productIdList = response.data;
											$scope.updateProductForm.message = null;
										},
										function(response) {
											$scope.productIdList = null;
											$scope.updateProductForm.message = response.data.message;
										});
					}

					$scope.updateProductForm.getProductById = function() {
						if ($scope.updateProductForm.productId == null) {
							$scope.flag = false;
						} else {
							$scope.updateProductForm.message = null;
							var data = angular.fromJson($scope.updateProductForm);
							data.productId=parseInt(data.productId);
							var responsePromise = $http.post(URI + "ProductAPI"
									+ "/productDetailsById", data);
							responsePromise
									.then(
											function(response) {
													$scope.updateProductForm.message = null;
													$scope.flag= true;
													$scope.updateProductForm.productName = response.data.name;
													$scope.updateProductForm.sellingPrice = response.data.sellingPrice;
													$scope.updateProductForm.quantity = response.data.quantity;
											},
											function(response) {
												$scope.flag = false;
												$scope.updateProductForm.productId = null;
												$scope.updateProductForm.productName = null;
												$scope.updateProductForm.sellingPrice = null;
												$scope.updateProductForm.quantity = null;
												$scope.updateProductForm.message = response.data.message;

											});
						}
					}

					$scope.updateProductForm.updateProduct = function() {
						$scope.updateProductForm.message = null;
						var data = angular.toJson($scope.updateProductForm);
						var responsePromise = $http.put(URI + "ProductAPI",
								data);
						responsePromise
								.then(
										function(response) {
											$scope.updateProductForm.message = response.data.message;
										},
										function(response) {
											$scope.updateProductForm.message = response.data.message;
										});
					}
				});

infyRetail
		.controller(
				"AdminDeleteProductController",

				function($scope, $http, $route) {
					$scope.allProductList = null;
					$scope.fetchAllProducts = function() {
						var responsePromise = $http.get(URI + "ProductAPI"
								+ "/allProductsList");

						responsePromise.then(function(response) {
							$scope.allProductList = response.data;

						}, function(response) {
							$scope.message = response.data.message;
						});
					}

					$scope.deleteProducts = function(item) {
						$scope.message = null;

						var data = angular.toJson(item.productId);

						 var responsePromise = $http.delete(URI + "ProductAPI/"+data);

						responsePromise
								.then(
										function(response) {
												$route.reload();
										},
										function(response) {
											$scope.message = response.data.message;
										});
					}
				});

infyRetail.controller("AdminAddProductController", function($scope, $http) {
	$scope.addProductForm = {};

	$scope.generateCategoryList = function() {
		var responsePromise = $http.get(URI + "ProductAPI" + "/category");

		responsePromise.then(function(response) {
			$scope.categoryList = response.data;

		}, function(response) {
			$scope.addProductForm.message = response.data.message;
		});
	}

	$scope.generateSupplierIdList = function() {
		var responsePromise = $http.get(URI + "UserAPI");

		responsePromise.then(function(response) {
			$scope.userIdList = response.data;

		}, function(response) {
			$scope.addProductForm.message = response.data.message;
		});
	}

	$scope.addProductForm.addProducts = function() {
		$scope.addProductForm.message = null;
		var data = angular.toJson($scope.addProductForm);
		var responsePromise = $http.post(URI + "ProductAPI", data);
		responsePromise.then(function(response) {
			$scope.addProductForm.message = response.data.message;
		}, function(response) {
			$scope.addProductForm.message = response.data.message;
		});
	}
});